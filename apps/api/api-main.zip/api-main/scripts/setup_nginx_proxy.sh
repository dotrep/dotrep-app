#!/usr/bin/env bash
# =========================
# FSN PROD NGINX TLS PROXY (PORT 443 -> APP :6000)
# =========================
set -euo pipefail

echo "==> Install nginx + openssl (if missing)"
apt-get update -y && apt-get install -y nginx openssl

echo "==> Generate self-signed cert (valid 365d)"
mkdir -p /etc/nginx/certs
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -subj "/CN=fsn.local" \
  -keyout /etc/nginx/certs/fsn.key \
  -out /etc/nginx/certs/fsn.crt

echo "==> Write nginx config"
cat > /etc/nginx/sites-available/fsn.conf <<'NGINX'
server {
    listen 80;
    server_name _;

    # Redirect everything to https
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl;
    server_name _;

    ssl_certificate     /etc/nginx/certs/fsn.crt;
    ssl_certificate_key /etc/nginx/certs/fsn.key;

    # Healthcheck endpoint
    location /health {
        access_log off;
        return 200 'OK';
    }

    # Proxy FSN app on port 6000
    location / {
        proxy_pass         http://127.0.0.1:6000;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade $http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Security headers
    add_header X-Content-Type-Options "nosniff";
    add_header X-Frame-Options "DENY";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    add_header Permissions-Policy "geolocation=(), microphone=(), camera=()";
}
NGINX

echo "==> Enable config"
ln -sfn /etc/nginx/sites-available/fsn.conf /etc/nginx/sites-enabled/fsn.conf
rm -f /etc/nginx/sites-enabled/default || true

echo "==> Reload nginx"
nginx -t && systemctl restart nginx

echo "==> ✅ Nginx proxy live"
echo "    - HTTPS:   https://localhost/ (proxying to app:6000)"
echo "    - Health:  https://localhost/health"
echo "    - Certs:   /etc/nginx/certs/fsn.{crt,key} (self-signed)"