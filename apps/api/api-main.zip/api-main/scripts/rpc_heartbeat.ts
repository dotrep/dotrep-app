import { rpc } from "../libs/rpc";
async function main() {
  const t = Date.now();
  try {
    const res = await rpc("eth_blockNumber", []);
    const ms = Date.now() - t;
    const block = parseInt(res.result, 16);
    console.log(JSON.stringify({ ts:new Date().toISOString(), ok:true, ms, block }));
    if (ms > 1200) console.error(JSON.stringify({ ts:new Date().toISOString(), warn:"slow_rpc", ms }));
  } catch (e:any) {
    console.error(JSON.stringify({ ts:new Date().toISOString(), ok:false, err: e?.message || String(e) }));
    process.exitCode = 1;
  }
}
main();
