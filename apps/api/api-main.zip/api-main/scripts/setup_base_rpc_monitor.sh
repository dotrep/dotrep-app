#!/usr/bin/env bash
# =========================
# FSN: BASE NODE PRIMARY + RPC HEALTHCHECK (1/min)
# =========================
set -euo pipefail

echo "==> 1) Env: Base Node primary, paid RPC fallback"
cat > .env.local <<'ENV'
BASE_RPC_PRIMARY=https://api.developer.coinbase.com/rpc/base
# Optional fallback (Chainstack/Alchemy/QuickNode). Leave blank if none yet:
BASE_RPC_SECONDARY=
RPC_TIMEOUT_MS=4000
RPC_MAX_RETRIES=2
ENV

echo "==> 2) Minimal RPC client with auto-failover"
mkdir -p libs scripts
cat > libs/rpc.ts <<'TS'
const P = process.env.BASE_RPC_PRIMARY!;
const S = process.env.BASE_RPC_SECONDARY || "";
const TIMEOUT = Number(process.env.RPC_TIMEOUT_MS || 4000);
const RETRIES = Number(process.env.RPC_MAX_RETRIES || 2);

async function post(ep: string, body: any) {
  const res = await fetch(ep, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(TIMEOUT),
  });
  if (!res.ok) throw new Error(String(res.status));
  return res.json();
}

export async function rpc(method: string, params: any[] = []) {
  const endpoints = [P, ...(S ? [S] : [])];
  for (const ep of endpoints) {
    try {
      return await post(ep, { jsonrpc: "2.0", id: 1, method, params });
    } catch (e: any) {
      const code = Number(e.message || 0);
      if (![429, 500, 502, 503, 504].includes(code)) {
        // non-retryable; try next endpoint if available
      }
    }
    // simple backoff between retries per endpoint
    for (let i = 0; i < RETRIES; i++) await new Promise(r => setTimeout(r, 300 * (i + 1)));
  }
  throw new Error("RPC failed (exhausted endpoints)");
}
TS

echo "==> 3) Healthcheck script (logs latency, flags rate limits)"
cat > scripts/rpc_healthcheck.ts <<'TS'
import { rpc } from "../libs/rpc";
async function main() {
  const start = Date.now();
  try {
    // cheap call: latest block number
    const res = await rpc("eth_blockNumber", []);
    const ms = Date.now() - start;
    const block = parseInt(res.result, 16);
    const ts = new Date().toISOString();
    const status = { ts, ok: true, ms, block };
    console.log(JSON.stringify(status));
    // alert condition examples:
    if (ms > 1200) console.error(JSON.stringify({ ts, warn: "slow_rpc", ms }));
  } catch (e: any) {
    const ts = new Date().toISOString();
    console.error(JSON.stringify({ ts, ok: false, error: e?.message || String(e) }));
    process.exitCode = 1;
  }
}
main();
TS

echo "==> 4) (Optional) Sepolia dry-run checker"
cat > scripts/sepolia_dry_run.ts <<'TS'
import { rpc } from "../libs/rpc";
// Swap primary to Base Sepolia in your env to use this; otherwise it still works for mainnet.
async function main() {
  const { result: chainId } = await rpc("eth_chainId", []);
  const { result: blockHex } = await rpc("eth_blockNumber", []);
  console.log(JSON.stringify({ chainId, block: parseInt(blockHex,16) }));
}
main();
TS

echo "==> 5) Package scripts"
node -e "let p=require('./package.json'); p.scripts=p.scripts||{}; p.scripts.rpc='tsx scripts/rpc_healthcheck.ts'; p.scripts.sepolia='tsx scripts/sepolia_dry_run.ts'; require('fs').writeFileSync('package.json', JSON.stringify(p,null,2));"

echo "==> 6) Install tsx if missing"
pnpm add -D tsx >/dev/null 2>&1 || true

echo "==> 7) Run once now, then keep it running every minute"
pnpm rpc || true
# simple 1/min loop (use a proper scheduler later)
nohup bash -c 'while true; do pnpm rpc; sleep 60; done' >/dev/null 2>&1 &
echo "==> ✅ Base Node wired as primary; healthcheck is logging every minute."
echo "    View logs with: tail -f nohup.out (if present) or your Replit console"
echo "    Optional Sepolia check: pnpm sepolia"