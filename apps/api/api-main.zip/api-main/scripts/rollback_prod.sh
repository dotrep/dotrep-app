#!/usr/bin/env bash
set -euo pipefail
CUR="releases/current-prod"
PIDFILE="shared/prod.pid"

if [[ -f "$PIDFILE" ]]; then
  PID="$(cat "$PIDFILE" || true)"
  if [[ -n "${PID:-}" ]] && ps -p "$PID" >/dev/null 2>&1; then
    echo "==> Stopping prod ($PID)"
    kill "$PID" || true
    sleep 1
  fi
  rm -f "$PIDFILE"
fi

PREV="$(ls -1 releases | grep -E '^prod-[0-9]{8}-[0-9]{6}$' | sort | tail -n 2 | head -n 1 || true)"
if [[ -z "$PREV" ]]; then
  echo "!! No previous prod release."
  exit 1
fi

echo "==> Rolling back to releases/$PREV"
ln -sfn "$PREV" "$CUR"

PORT="$(grep '^PORT=' .env.prod | cut -d= -f2 2>/dev/null || echo "6000")"
RDIR="$(readlink -f "$CUR")"
WORKSPACE_ROOT=$(pwd)
(
  cd "$RDIR"
  set -a
  . ./.env   # export all vars from .env
  set +a
  nohup bash -lc 'exec node dist/index.js' > prod.out 2>&1 &
  echo $! > "$WORKSPACE_ROOT/$PIDFILE"
)
echo "==> Rollback complete: http://localhost:$PORT"