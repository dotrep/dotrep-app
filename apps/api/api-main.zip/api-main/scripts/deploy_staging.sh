#!/usr/bin/env bash
set -euo pipefail

PORT=5002
TS="$(date +%Y%m%d-%H%M%S)"
REL="releases/$TS"
CUR="releases/current"
PIDFILE="shared/staging.pid"
ENVFILE="$REL/.env"
LOG="$REL/deploy.log"

echo "==> Creating release $REL"
mkdir -p "$REL"
echo "==> Creating release $REL" | tee -a "$LOG"
rsync -a --delete apps packages "$REL"/

# Staging env
cat > "$ENVFILE" <<ENV
NODE_ENV=staging
PORT=$PORT
BASE_CHAIN=8453
STAGING_DB=sqlite://staging.sqlite
ENV

echo "==> Building workspace" | tee -a "$LOG"
pnpm -w build | tee -a "$LOG"

echo "==> Linking current -> $TS"
ln -sfn "$TS" "releases/current"

# Create shared directory if it doesn't exist
mkdir -p shared

# Install dependencies and start server (background)
echo "==> Installing dependencies" | tee -a "$LOG"
( cd "$CUR/apps/mini" && pnpm install )

echo "==> Starting staging on :$PORT" | tee -a "$LOG"
WORKSPACE_ROOT=$(pwd)
( cd "$CUR/apps/mini" && PORT=$PORT nohup pnpm dev > "../../staging.out" 2>&1 & echo $! > "$WORKSPACE_ROOT/$PIDFILE" )

sleep 10

# 🔎 Health check (prefer QA routes from your screenshots)
echo "==> Health check" | tee -a "$LOG"
for path in "/" "/qa/wallet" "/qa/flags"; do
  if curl -fsS "http://localhost:$PORT$path" >/dev/null 2>&1; then
    echo "OK: $path" | tee -a "$LOG"
    echo "==> Staging deployed: http://localhost:$PORT" | tee -a "$LOG"
    exit 0
  fi
done

echo "!! Health check failed, rolling back" | tee -a "$LOG"
bash scripts/rollback_staging.sh
exit 1