#!/usr/bin/env bash
set -euo pipefail
URL="${1:-http://localhost:6000/api/claim}"
npx autocannon -d 15 -c 80 "$URL"