#!/usr/bin/env bash
set -euo pipefail
LOG="${1:-releases/current/migrate.log}"
if command -v pnpm >/dev/null 2>&1 && pnpm -w run | grep -q "prisma"; then
  echo "==> Running prisma migrate" | tee -a "$LOG"
  pnpm -w prisma migrate deploy | tee -a "$LOG"
  echo "==> Prisma migrate OK" | tee -a "$LOG"
else
  echo "==> Prisma not configured; skipping DB migrate" | tee -a "$LOG"
fi