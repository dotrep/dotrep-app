#!/usr/bin/env bash
set -euo pipefail
URL="${1:-http://localhost:6000/health}"
TS=$(date +%Y-%m-%dT%H:%M:%S)
if curl -fsS "$URL" >/dev/null; then
  echo "$TS OK"
else
  echo "$TS FAIL"
  exit 1
fi