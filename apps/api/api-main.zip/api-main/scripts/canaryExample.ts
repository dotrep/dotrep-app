/**
 * Example: percent rollout by hashing a stable key (userId, wallet, etc)
 */
import crypto from "node:crypto";
type Feature = { enabled: boolean; rollout: number };
type Flags = { features: Record<string, Feature> };

export function isEnabled(flags: Flags, name: string, stableKey: string) {
  const f = flags.features[name];
  if (!f) return false;
  if (!f.enabled) return false;
  const h = crypto.createHash("sha1").update(stableKey).digest();
  const bucket = h[0] % 100; // 0..99
  return bucket < (f.rollout ?? 0);
}