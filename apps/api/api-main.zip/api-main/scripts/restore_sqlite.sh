#!/usr/bin/env bash
set -euo pipefail
BAK="${1:?Usage: restore_sqlite.sh backups/<file>.bak}"
DST="${2:-releases/current/staging.sqlite}"
cp -f "$BAK" "$DST"
echo "✅ Restored $BAK -> $DST"
