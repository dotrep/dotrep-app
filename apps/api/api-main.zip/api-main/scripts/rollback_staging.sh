#!/usr/bin/env bash
set -euo pipefail

CUR="releases/current"
PIDFILE="shared/staging.pid"

# Stop current if running
if [[ -f "$PIDFILE" ]]; then
  PID="$(cat "$PIDFILE" || true)"
  if [[ -n "${PID:-}" ]] && ps -p "$PID" >/dev/null 2>&1; then
    echo "==> Stopping current staging (PID $PID)"
    kill "$PID" || true
    sleep 1
  fi
  rm -f "$PIDFILE"
fi

# Pick previous release
PREV="$(ls -1 releases | grep -E '^[0-9]{8}-[0-9]{6}$' | sort | tail -n 2 | head -n 1 || true)"
if [[ -z "$PREV" ]]; then
  echo "!! No previous release found to roll back to."
  exit 1
fi

echo "==> Rolling back to releases/$PREV"
ln -sfn "releases/$PREV" "$CUR"

# Restart previous
PORT=5002
WORKSPACE_ROOT=$(pwd)
( cd "$CUR/apps/mini" && nohup pnpm start --port "$PORT" > "../../staging.out" 2>&1 & echo $! > "$WORKSPACE_ROOT/$PIDFILE" )
echo "==> Rollback complete: http://localhost:$PORT"