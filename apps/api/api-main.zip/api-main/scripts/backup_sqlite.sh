#!/usr/bin/env bash
set -euo pipefail
SRC="${1:-releases/current/staging.sqlite}"
TS=$(date +%Y%m%d-%H%M%S)
mkdir -p backups
cp -f "$SRC" "backups/$(basename "$SRC").$TS.bak"
echo "✅ Backup created: backups/$(basename "$SRC").$TS.bak"
