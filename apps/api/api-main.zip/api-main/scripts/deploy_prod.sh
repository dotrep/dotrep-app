#!/usr/bin/env bash
set -euo pipefail

# Load prod env
if [[ ! -f .env.prod ]]; then
  cat <<'ENV' > .env.prod
NODE_ENV=production
PORT=6000
BASE_CHAIN=8453
STAGING_AUTH_USER=
STAGING_AUTH_PASS=
SENTRY_DSN=
LOG_LEVEL=info
ENV
  echo "!! Created .env.prod template. Fill secrets, then re-run."
  exit 1
fi
export $(grep -v '^#' .env.prod | xargs -d '\n' -I {} echo {})

TS="$(date +%Y%m%d-%H%M%S)"
REL="releases/prod-$TS"
CUR="releases/current-prod"
PIDFILE="shared/prod.pid"
LOG="$REL/deploy.log"

mkdir -p "$REL"
echo "==> Install + build" | tee -a "$LOG"
pnpm -w install --frozen-lockfile || pnpm -w install
pnpm -w build | tee -a "$LOG"
echo "==> Create prod release $REL" | tee -a "$LOG"
rsync -a --delete apps packages config dist "$REL"/ || true
cp .env.prod "$REL/.env"

echo "==> Link blue/green: current-prod -> prod-$TS" | tee -a "$LOG"
ln -sfn "prod-$TS" "$CUR"

# Stop old
if [[ -f "$PIDFILE" ]]; then
  OLD="$(cat "$PIDFILE" || true)"
  if [[ -n "${OLD:-}" ]] && ps -p "$OLD" >/dev/null 2>&1; then
    echo "==> Stopping old prod ($OLD)" | tee -a "$LOG"
    kill "$OLD" || true
    sleep 1
  fi
fi

# Create shared directory if needed
mkdir -p shared

# Start new (using built production server)
echo "==> Starting prod on :$PORT" | tee -a "$LOG"
RDIR="$(readlink -f "$CUR")"
WORKSPACE_ROOT=$(pwd)
(
  cd "$RDIR"
  set -a
  . ./.env   # export all vars from .env
  set +a
  nohup bash -lc 'exec node dist/index.js' > prod.out 2>&1 &
  echo $! > "$WORKSPACE_ROOT/$PIDFILE"
)

sleep 2

# Quick verify process is still alive
if ! ps -p "$(cat "$PIDFILE" 2>/dev/null || echo '')" >/dev/null 2>&1; then
  echo "!! Prod died immediately, see $RDIR/prod.out"
  tail -50 "$RDIR/prod.out" || true
  exit 1
fi

# Health check (must pass all checks)
echo "==> Health check" | tee -a "$LOG"
HEALTH_PASSED=false
for path in "/" "/health" "/qa/flags"; do
  if curl -fsS "http://localhost:$PORT$path" >/dev/null 2>&1; then
    echo "OK: $path" | tee -a "$LOG"
    HEALTH_PASSED=true
    break
  fi
done

if [[ "$HEALTH_PASSED" != "true" ]]; then
  echo "!! Health check failed, rolling back" | tee -a "$LOG"
  bash scripts/rollback_prod.sh
  exit 1
fi

echo "==> DB migrate guard" | tee -a "$LOG"
bash scripts/migrate_safe.sh "$REL/migrate.log" || { echo "!! Migrate failed"; exit 1; }

echo "==> ✅ Prod live at http://localhost:$PORT" | tee -a "$LOG"