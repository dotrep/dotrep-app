#!/usr/bin/env bash
set -euo pipefail
URL="${1:-http://localhost:6000}"
H=$(curl -s -D - "$URL" -o /dev/null)
need=("content-security-policy" "x-content-type-options" "x-frame-options" "referrer-policy" "permissions-policy")
fail=0
for k in "${need[@]}"; do
  if echo "$H" | grep -i -q "^$k:"; then echo "✅ $k present"; else echo "❌ $k missing"; fail=1; fi
done
exit $fail
