#!/usr/bin/env bash
# =========================
# FSN HARDENING PACK (Replit)
# Healthcheck • Sentry • Backups • Sec headers • Perf test
# =========================
set -euo pipefail

echo "==> 1) Ensure directories"
mkdir -p apps/mini/src/app/health scripts backups shared

echo "==> 2) Healthcheck endpoint (Next.js app route: /health -> 200 OK)"
cat > apps/mini/src/app/health/route.ts <<'TS'
export async function GET() {
  return new Response("OK", { status: 200, headers: { "content-type": "text/plain" }});
}
TS

echo "==> 3) Env scaffolding (edit DSN later if needed)"
touch .env.prod .env.staging .env.local
grep -q '^SENTRY_DSN=' .env.prod     || echo 'SENTRY_DSN='     >> .env.prod
grep -q '^SENTRY_DSN=' .env.staging  || echo 'SENTRY_DSN='     >> .env.staging
grep -q '^SENTRY_DSN=' .env.local    || echo 'SENTRY_DSN='     >> .env.local
grep -q '^LOG_LEVEL='  .env.prod     || echo 'LOG_LEVEL=info'  >> .env.prod

echo "==> 4) Add minimal Sentry wiring (only activates if SENTRY_DSN is set)"
pnpm add -D @sentry/nextjs >/dev/null 2>&1 || true

# sentry.client.config.ts
cat > apps/mini/sentry.client.config.ts <<'TS'
import * as Sentry from "@sentry/nextjs";
if (process.env.NEXT_PUBLIC_SENTRY_DSN || process.env.SENTRY_DSN) {
  Sentry.init({
    dsn: process.env.NEXT_PUBLIC_SENTRY_DSN || process.env.SENTRY_DSN,
    tracesSampleRate: 0.1,
  });
}
TS

# sentry.server.config.ts
cat > apps/mini/sentry.server.config.ts <<'TS'
import * as Sentry from "@sentry/nextjs";
if (process.env.SENTRY_DSN) {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    tracesSampleRate: 0.1,
  });
}
TS

# next.config.js patch (make sure Sentry files load)
if [ ! -f apps/mini/next.config.js ]; then echo 'module.exports = { reactStrictMode: true };' > apps/mini/next.config.js; fi
if ! grep -q "sentry" apps/mini/next.config.js; then
  cat >> apps/mini/next.config.js <<'JS'

// Sentry: mark config present (runtime imports reside in app/_app or layout as needed)
console.log("[Sentry] config loaded (init happens via sentry.*.config.ts if DSN present)");
JS
fi

echo "==> 5) RPC heartbeat (latency log every minute)"
mkdir -p libs
cat > libs/rpc.ts <<'TS'
const P = process.env.BASE_RPC_PRIMARY || "https://api.developer.coinbase.com/rpc/base";
const S = process.env.BASE_RPC_SECONDARY || "";
const TIMEOUT = Number(process.env.RPC_TIMEOUT_MS || 4000);
const RETRIES = Number(process.env.RPC_MAX_RETRIES || 2);
async function post(ep, body) {
  const res = await fetch(ep, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body), signal: AbortSignal.timeout(TIMEOUT) });
  if (!res.ok) throw new Error(String(res.status));
  return res.json();
}
export async function rpc(method, params = []) {
  const eps = [P, ...(S ? [S] : [])];
  for (const ep of eps) {
    try { return await post(ep, { jsonrpc: "2.0", id: 1, method, params }); }
    catch (e) { /* try next / backoff */ for (let i=0;i<RETRIES;i++) await new Promise(r=>setTimeout(r,300*(i+1))); }
  }
  throw new Error("RPC failed (exhausted endpoints)");
}
TS

cat > scripts/rpc_heartbeat.ts <<'TS'
import { rpc } from "../libs/rpc";
async function main() {
  const t = Date.now();
  try {
    const res = await rpc("eth_blockNumber", []);
    const ms = Date.now() - t;
    const block = parseInt(res.result, 16);
    console.log(JSON.stringify({ ts:new Date().toISOString(), ok:true, ms, block }));
    if (ms > 1200) console.error(JSON.stringify({ ts:new Date().toISOString(), warn:"slow_rpc", ms }));
  } catch (e:any) {
    console.error(JSON.stringify({ ts:new Date().toISOString(), ok:false, err: e?.message || String(e) }));
    process.exitCode = 1;
  }
}
main();
TS

echo "==> 6) Security header smoke-check script (expects your app at http://localhost:6000 or 5002)"
cat > scripts/sec_headers_check.sh <<'BASH'
#!/usr/bin/env bash
set -euo pipefail
URL="${1:-http://localhost:6000}"
H=$(curl -s -D - "$URL" -o /dev/null)
need=("content-security-policy" "x-content-type-options" "x-frame-options" "referrer-policy" "permissions-policy")
fail=0
for k in "${need[@]}"; do
  if echo "$H" | grep -i -q "^$k:"; then echo "✅ $k present"; else echo "❌ $k missing"; fail=1; fi
done
exit $fail
BASH
chmod +x scripts/sec_headers_check.sh

echo "==> 7) SQLite backup + restore drill (staging/prod)"
cat > scripts/backup_sqlite.sh <<'BASH'
#!/usr/bin/env bash
set -euo pipefail
SRC="${1:-releases/current/staging.sqlite}"
TS=$(date +%Y%m%d-%H%M%S)
mkdir -p backups
cp -f "$SRC" "backups/$(basename "$SRC").$TS.bak"
echo "✅ Backup created: backups/$(basename "$SRC").$TS.bak"
BASH
chmod +x scripts/backup_sqlite.sh

cat > scripts/restore_sqlite.sh <<'BASH'
#!/usr/bin/env bash
set -euo pipefail
BAK="${1:?Usage: restore_sqlite.sh backups/<file>.bak}"
DST="${2:-releases/current/staging.sqlite}"
cp -f "$BAK" "$DST"
echo "✅ Restored $BAK -> $DST"
BASH
chmod +x scripts/restore_sqlite.sh

echo "==> 8) Quick perf test (autocannon burst) against local URL"
pnpm add -D autocannon tsx >/dev/null 2>&1 || true
cat > scripts/perf_burst.sh <<'BASH'
#!/usr/bin/env bash
set -euo pipefail
URL="${1:-http://localhost:5002/}"
npx autocannon -d 15 -c 80 "$URL"
BASH
chmod +x scripts/perf_burst.sh

echo "==> 9) Add npm scripts"
node - <<'JS'
const fs = require('fs'); const p=JSON.parse(fs.readFileSync('package.json','utf8'));
p.scripts = p.scripts || {};
p.scripts["health:rpc"] = "tsx scripts/rpc_heartbeat.ts";
p.scripts["sec:headers"] = "bash scripts/sec_headers_check.sh";
p.scripts["db:backup"] = "bash scripts/backup_sqlite.sh";
p.scripts["db:restore"] = "bash scripts/restore_sqlite.sh";
p.scripts["perf:test"] = "bash scripts/perf_burst.sh";
fs.writeFileSync('package.json', JSON.stringify(p,null,2));
console.log("✅ package.json scripts added");
JS

echo "==> 10) Start RPC heartbeat (every 60s) in background"
nohup bash -c 'while true; do pnpm health:rpc || true; sleep 60; done' >/dev/null 2>&1 &

echo "==> ✅ Hardening pack installed."
echo "Run examples:"
echo "  pnpm sec:headers             # check security headers"
echo "  pnpm db:backup               # snapshot SQLite (adjust path in script if needed)"
echo "  pnpm db:restore backups/<file>.bak  # restore"
echo "  pnpm perf:test               # 15s burst to your local URL"
echo "Note:"
echo "  • Set SENTRY_DSN in .env.staging/.env.prod to enable error reporting."
echo "  • /health is now live (Next.js route)."