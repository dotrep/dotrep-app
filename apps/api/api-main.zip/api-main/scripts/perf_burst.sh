#!/usr/bin/env bash
set -euo pipefail
URL="${1:-http://localhost:5002/}"
npx autocannon -d 15 -c 80 "$URL"
