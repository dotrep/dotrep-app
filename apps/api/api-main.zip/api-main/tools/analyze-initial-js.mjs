import fs from 'node:fs';
import path from 'node:path';

function kb(n) { return Math.round((n/1024)*10)/10; }

function readManifest(base) {
  const apps = ['app-build-manifest.json','build-manifest.json'];
  for (const f of apps) {
    const p = path.join(base, '.next', f);
    if (fs.existsSync(p)) return { p, j: JSON.parse(fs.readFileSync(p, 'utf8')) };
  }
  throw new Error('No build manifest found');
}

function sizeForRoot(j) {
  // Try app router first - look for page routes
  const pageRoutes = ['/page', '/layout', '/'];
  
  for (const route of pageRoutes) {
    if (j.pages?.[route]) {
      const chunks = j.pages[route];
      const files = new Set([...(j.runtime || []), ...chunks]);
      let total = 0;
      for (const f of files) {
        const fp = path.join('.next', f.replace(/^\//,''));
        if (fs.existsSync(fp)) total += fs.statSync(fp).size;
      }
      return { total, files: [...files], route };
    }
  }
  
  // If no specific route found, use layout + page combination for app router
  if (j.pages?.['/layout']) {
    const layoutChunks = j.pages['/layout'] || [];
    const pageChunks = Object.keys(j.pages).find(k => k.includes('/page')) ? 
                      j.pages[Object.keys(j.pages).find(k => k.includes('/page'))] || [] : [];
    
    const files = new Set([...(j.runtime || []), ...layoutChunks, ...pageChunks]);
    let total = 0;
    for (const f of files) {
      const fp = path.join('.next', f.replace(/^\//,''));
      if (fs.existsSync(fp)) total += fs.statSync(fp).size;
    }
    return { total, files: [...files], route: '/layout+page' };
  }
  
  throw new Error('Cannot locate root route in manifest');
}

const { j } = readManifest(process.cwd());
const { total, files } = sizeForRoot(j);
const totalKB = kb(total);
console.log(JSON.stringify({ initialKB: totalKB, files }, null, 2));
if (totalKB > 250) {
  console.error(`FAIL: Initial JS ${totalKB} KB > 250 KB`);
  process.exit(1);
} else {
  console.log(`PASS: Initial JS ${totalKB} KB ≤ 250 KB`);
}