/**
 * ERC-4337 Paymaster Service for Gasless FSN Claiming
 * 
 * Handles UserOperation construction and paymaster sponsorship
 * for gasless FSN identity claiming on Base network.
 */

import crypto from 'crypto';
import { z } from 'zod';
import { paymasterGuard } from '../src/paymaster/guard';
import { telemetry } from '../src/telemetry';
import { config, getPaymasterConfig } from '../src/config';

// Types for ERC-4337 UserOperations
export interface UserOperation {
  sender: string;
  nonce: string;
  initCode: string;
  callData: string;
  callGasLimit: string;
  verificationGasLimit: string;
  preVerificationGas: string;
  maxFeePerGas: string;
  maxPriorityFeePerGas: string;
  paymasterAndData: string;
  signature: string;
}

export interface PaymasterResult {
  success: boolean;
  userOpHash?: string;
  txHash?: string;
  error?: string;
  sponsoredGas?: boolean;
}

// Validation schemas
const walletAddressSchema = z.string().regex(/^0x[a-fA-F0-9]{40}$/);
const fsnNameSchema = z.string().min(3).max(20).regex(/^[a-zA-Z0-9_-]+$/);

export class PaymasterService {
  private readonly paymasterUrl: string;
  private readonly chainId: number;
  private readonly allowedWallets: string[];

  constructor() {
    const paymasterConfig = getPaymasterConfig();
    this.paymasterUrl = paymasterConfig.url;
    this.chainId = paymasterConfig.chainId;
    this.allowedWallets = paymasterConfig.allowedWallets;
  }

  /**
   * Check if paymaster feature is enabled
   */
  isEnabled(): boolean {
    return config.ENABLE_PAYMASTER;
  }

  /**
   * Comprehensive pre-flight check for paymaster eligibility
   */
  async preflightCheck(walletAddress: string, walletType: string, requestId: string, estimatedCostCents: number = 50): Promise<{
    eligible: boolean;
    reason?: string;
    remainingBudgetCents?: number;
  }> {
    try {
      // Basic feature check
      if (!this.isEnabled()) {
        return {
          eligible: false,
          reason: 'Paymaster feature is disabled'
        };
      }

      // Wallet validation
      const walletCheck = await this.validateWallet(walletAddress, walletType);
      if (!walletCheck.eligible) {
        return walletCheck;
      }

      // Safety guard checks (spend caps, QPS limits)
      const guardCheck = await paymasterGuard.checkAllowed(walletAddress, estimatedCostCents);
      if (!guardCheck.allowed) {
        telemetry.paymasterCall(requestId, walletAddress, 0, 'error', guardCheck.reason);
        return {
          eligible: false,
          reason: guardCheck.reason,
          remainingBudgetCents: guardCheck.remainingBudgetCents
        };
      }

      return {
        eligible: true,
        remainingBudgetCents: guardCheck.remainingBudgetCents
      };
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown preflight error';
      telemetry.paymasterCall(requestId, walletAddress, 0, 'error', errorMessage);
      
      return {
        eligible: false,
        reason: `Preflight check failed: ${errorMessage}`
      };
    }
  }

  /**
   * Validate wallet eligibility for gasless transactions
   */
  async validateWallet(walletAddress: string, walletType: string): Promise<{
    eligible: boolean;
    reason?: string;
  }> {
    try {
      // Validate input
      walletAddressSchema.parse(walletAddress);
      
      if (!this.allowedWallets.includes(walletType)) {
        return {
          eligible: false,
          reason: `Wallet type ${walletType} not supported for gasless transactions`,
        };
      }

      // Check wallet activity (simplified for Phase 0)
      // In production, check for minimum balance, transaction history, etc.
      const isActive = true; // Placeholder - implement actual checks

      if (!isActive) {
        return {
          eligible: false,
          reason: 'Wallet does not meet activity requirements',
        };
      }

      return { eligible: true };

    } catch (error) {
      return {
        eligible: false,
        reason: 'Invalid wallet address format',
      };
    }
  }

  /**
   * Construct UserOperation for FSN claiming
   */
  async constructUserOp(
    walletAddress: string,
    fsnName: string,
    nonce: number = 0
  ): Promise<UserOperation> {
    // Validate inputs
    walletAddressSchema.parse(walletAddress);
    fsnNameSchema.parse(fsnName);

    // Construct the UserOperation
    // In a real implementation, this would build actual contract call data
    const userOp: UserOperation = {
      sender: walletAddress,
      nonce: `0x${nonce.toString(16)}`,
      initCode: '0x', // Empty for existing wallets
      callData: this.buildClaimCallData(fsnName),
      callGasLimit: '0x186A0', // 100,000 gas
      verificationGasLimit: '0x186A0', // 100,000 gas
      preVerificationGas: '0x5208', // 21,000 gas
      maxFeePerGas: '0x59682F00', // 1.5 gwei
      maxPriorityFeePerGas: '0x3B9ACA00', // 1 gwei
      paymasterAndData: '0x', // Will be filled by paymaster
      signature: '0x', // Will be signed by wallet
    };

    return userOp;
  }

  /**
   * Request paymaster sponsorship for a UserOperation
   */
  async requestSponsorship(
    userOp: UserOperation,
    walletType: string,
    deviceId?: string
  ): Promise<PaymasterResult> {
    if (!this.isEnabled()) {
      return {
        success: false,
        error: 'Paymaster service is disabled',
      };
    }

    try {
      // Validate wallet eligibility
      const validation = await this.validateWallet(userOp.sender, walletType);
      if (!validation.eligible) {
        return {
          success: false,
          error: validation.reason || 'Wallet not eligible for gasless transactions',
        };
      }

      // In Phase 0, we simulate the paymaster call
      if (process.env.NODE_ENV === 'development') {
        return this.simulatePaymasterResponse(userOp);
      }

      // Make actual paymaster request
      const response = await this.callPaymaster(userOp, deviceId);
      return response;

    } catch (error) {
      console.error('Paymaster sponsorship error:', error);
      return {
        success: false,
        error: 'Failed to request paymaster sponsorship',
      };
    }
  }

  /**
   * Submit sponsored UserOperation to the network
   */
  async submitUserOperation(
    userOp: UserOperation,
    signature: string
  ): Promise<PaymasterResult> {
    try {
      // Add signature to UserOp
      const signedUserOp = {
        ...userOp,
        signature,
      };

      // In Phase 0, simulate transaction submission
      if (process.env.NODE_ENV === 'development') {
        const mockTxHash = '0x' + crypto.randomBytes(32).toString('hex');
        return {
          success: true,
          txHash: mockTxHash,
          sponsoredGas: true,
        };
      }

      // Submit to actual bundler/network
      const result = await this.submitToBundler(signedUserOp);
      return result;

    } catch (error) {
      console.error('UserOperation submission error:', error);
      return {
        success: false,
        error: 'Failed to submit UserOperation',
      };
    }
  }

  /**
   * Build call data for FSN claiming contract interaction
   */
  private buildClaimCallData(fsnName: string): string {
    // This would construct the actual contract call data
    // For now, return encoded function call placeholder
    const functionSelector = '0x1e83409a'; // claimFSN(string)
    const encodedName = this.encodeString(fsnName);
    return functionSelector + encodedName.slice(2);
  }

  /**
   * Encode string parameter for contract calls
   */
  private encodeString(value: string): string {
    // Simplified ABI encoding for string parameter
    const buffer = Buffer.from(value, 'utf8');
    const length = buffer.length.toString(16).padStart(64, '0');
    const data = buffer.toString('hex').padEnd(64, '0');
    return '0x' + length + data;
  }

  /**
   * Simulate paymaster response for development
   */
  private simulatePaymasterResponse(userOp: UserOperation): PaymasterResult {
    // Generate mock paymaster data
    const mockPaymasterAddress = '0x' + '1'.repeat(40);
    const mockPaymasterData = '0x' + crypto.randomBytes(32).toString('hex');
    
    // Update UserOp with paymaster data
    userOp.paymasterAndData = mockPaymasterAddress + mockPaymasterData.slice(2);

    const mockUserOpHash = '0x' + crypto.randomBytes(32).toString('hex');

    console.log(`🎯 Paymaster simulation: Sponsoring gas for ${userOp.sender}`);

    return {
      success: true,
      userOpHash: mockUserOpHash,
      sponsoredGas: true,
    };
  }

  /**
   * Make actual HTTP call to paymaster service
   */
  private async callPaymaster(
    userOp: UserOperation,
    deviceId?: string
  ): Promise<PaymasterResult> {
    const response = await fetch(this.paymasterUrl + '/sponsor', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Device-ID': deviceId || 'unknown',
      },
      body: JSON.stringify({
        userOp,
        chainId: this.chainId,
        context: {
          type: 'fsn_claim',
          version: '0.1.0-phase0',
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Paymaster request failed: ${response.status}`);
    }

    const data = await response.json();
    return {
      success: true,
      userOpHash: data.userOpHash,
      sponsoredGas: true,
    };
  }

  /**
   * Submit UserOperation to bundler
   */
  private async submitToBundler(userOp: UserOperation): Promise<PaymasterResult> {
    // In real implementation, submit to ERC-4337 bundler
    const bundlerUrl = process.env.BUNDLER_URL || 'https://bundler.base.org';
    
    const response = await fetch(bundlerUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        jsonrpc: '2.0',
        method: 'eth_sendUserOperation',
        params: [userOp, process.env.ENTRY_POINT_ADDRESS || '0x5FF137D4b0FDCD49DcA30c7CF57E578a026d2789'],
        id: 1,
      }),
    });

    if (!response.ok) {
      throw new Error(`Bundler request failed: ${response.status}`);
    }

    const data = await response.json();
    return {
      success: true,
      userOpHash: data.result,
      sponsoredGas: true,
    };
  }

  /**
   * Monitor UserOperation status
   */
  async getOperationStatus(userOpHash: string): Promise<{
    status: 'pending' | 'success' | 'failed';
    txHash?: string;
    blockNumber?: number;
    gasUsed?: string;
  }> {
    // Implementation would query the bundler/network for status
    // For Phase 0, return mock status
    return {
      status: 'success',
      txHash: '0x' + crypto.randomBytes(32).toString('hex'),
      blockNumber: Math.floor(Math.random() * 1000000),
      gasUsed: '0x5208',
    };
  }
}

// Export singleton instance
export const paymasterService = new PaymasterService();