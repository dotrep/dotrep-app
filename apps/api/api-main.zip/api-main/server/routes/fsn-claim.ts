// FSN Phase 0 - Identity claiming route
import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db';
import { fsnIdentity, users, xpEvents, abuseLog } from '../../shared/schema';
import { eq, count } from 'drizzle-orm';
import crypto from 'crypto';

const router = Router();

// Feature flag check
const ENABLE_PAYMASTER = process.env.ENABLE_PAYMASTER === 'true';
const ALLOWED_WALLETS = process.env.ALLOWED_WALLETS?.split(',') || ['coinbase', 'metamask'];

// Validation schema for FSN identity claim
const claimSchema = z.object({
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/, 'Invalid wallet address'),
  fsnName: z.string()
    .min(3, 'FSN name must be at least 3 characters')
    .max(50, 'FSN name must be at most 50 characters')
    .regex(/^[a-zA-Z0-9_-]+$/, 'FSN name can only contain letters, numbers, underscores, and hyphens'),
  walletType: z.enum(['coinbase', 'metamask']),
  txHash: z.string().regex(/^0x[a-fA-F0-9]{64}$/, 'Invalid transaction hash').optional(),
  deviceId: z.string().optional(),
  userAgent: z.string().optional()
});

// POST /api/claim - Handle Coinbase Wallet claim with Paymaster subsidized transaction
router.post('/claim', async (req, res) => {
  try {
    // Check for idempotency key
    const idempotencyKey = req.headers['x-idempotency-key'] as string;
    if (!idempotencyKey) {
      return res.status(400).json({
        error: 'Request must include x-idempotency-key header',
        code: 'MISSING_IDEMPOTENCY_KEY'
      });
    }

    // Feature flag check
    if (!ENABLE_PAYMASTER) {
      return res.status(503).json({ 
        error: 'FSN claiming is currently disabled',
        code: 'CLAIMING_DISABLED' 
      });
    }

    // Validate request body
    const result = claimSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({
        error: 'Please check your input. FSN names must be 3-50 characters with only letters, numbers, underscores, and hyphens.',
        details: result.error.issues,
        code: 'VALIDATION_ERROR'
      });
    }

    const { walletAddress, fsnName, walletType, txHash, deviceId, userAgent } = result.data;

    // Check if wallet type is allowed
    if (!ALLOWED_WALLETS.includes(walletType)) {
      return res.status(400).json({
        error: `Wallet type ${walletType} is not allowed`,
        allowedWallets: ALLOWED_WALLETS,
        code: 'WALLET_NOT_ALLOWED'
      });
    }

    // Log abuse prevention data
    const ipHash = crypto.createHash('sha256')
      .update(req.ip + 'salt_for_privacy')
      .digest('hex');

    // Check if FSN name is already taken
    const existingName = await db
      .select()
      .from(fsnIdentity)
      .where(eq(fsnIdentity.fsnName, fsnName))
      .limit(1);

    if (existingName.length > 0) {
      // Log abuse attempt
      await db.insert(abuseLog).values({
        userId: walletAddress,
        deviceId: deviceId || null,
        ipHash,
        event: 'duplicate_fsn_claim',
        metadata: { fsnName, walletType }
      });

      return res.status(409).json({
        error: 'Name is taken. Try a variation.',
        code: 'NAME_TAKEN'
      });
    }

    // Check if wallet already has an FSN identity (soulbound rule)
    const existingIdentity = await db
      .select()
      .from(fsnIdentity)
      .where(eq(fsnIdentity.userId, walletAddress))
      .limit(1);

    if (existingIdentity.length > 0) {
      // Log abuse attempt
      await db.insert(abuseLog).values({
        userId: walletAddress,
        deviceId: deviceId || null,
        ipHash,
        event: 'duplicate_wallet_claim',
        metadata: { existingName: existingIdentity[0].fsnName, attemptedName: fsnName }
      });

      return res.status(409).json({
        error: 'Wallet already has an FSN identity. FSN names are soulbound to wallets.',
        existingName: existingIdentity[0].fsnName,
        code: 'WALLET_ALREADY_CLAIMED'
      });
    }

    // Create FSN identity
    const newIdentity = await db.insert(fsnIdentity).values({
      userId: walletAddress,
      fsnName,
      walletType,
      txHash: txHash || null,
      claimedAt: new Date()
    }).returning();

    // Create or update user record
    await db.insert(users).values({
      address: walletAddress,
      name: fsnName,
      streak: 0,
      xpMirror: 0,
      lastSeen: new Date()
    }).onConflictDoUpdate({
      target: users.address,
      set: {
        name: fsnName,
        lastSeen: new Date()
      }
    });

    // Award initial XP for claiming FSN identity
    const claimXP = 50; // Base XP for claiming
    await db.insert(xpEvents).values({
      userId: walletAddress,
      type: 'fsn_claim',
      points: claimXP,
      metadata: { fsnName, walletType }
    });

    // Update user XP mirror
    await db
      .update(users)
      .set({ xpMirror: claimXP })
      .where(eq(users.address, walletAddress));

    // Log successful claim
    await db.insert(abuseLog).values({
      userId: walletAddress,
      deviceId: deviceId || null,
      ipHash,
      event: 'successful_claim',
      metadata: { fsnName, walletType, xpAwarded: claimXP }
    });

    // Return success response
    res.json({
      success: true,
      identity: newIdentity[0],
      xpAwarded: claimXP,
      message: `Welcome to FSN! You've claimed ${fsnName}.fsn and earned ${claimXP} XP.`
    });

  } catch (error) {
    console.error('FSN claim error:', error);
    res.status(500).json({
      error: 'Internal server error during FSN claim',
      code: 'CLAIM_ERROR'
    });
  }
});

// GET /api/claim/check/:name - Check if FSN name is available
router.get('/check/:name', async (req, res) => {
  try {
    const fsnName = req.params.name;

    // Basic validation
    if (!fsnName || fsnName.length < 3 || fsnName.length > 50) {
      return res.status(400).json({
        error: 'Invalid FSN name length',
        code: 'INVALID_NAME'
      });
    }

    if (!/^[a-zA-Z0-9_-]+$/.test(fsnName)) {
      return res.status(400).json({
        error: 'Invalid FSN name format',
        code: 'INVALID_FORMAT'
      });
    }

    const existing = await db
      .select()
      .from(fsnIdentity)
      .where(eq(fsnIdentity.fsnName, fsnName))
      .limit(1);

    res.json({
      available: existing.length === 0,
      name: fsnName
    });

  } catch (error) {
    console.error('FSN name check error:', error);
    res.status(500).json({
      error: 'Error checking FSN name availability',
      code: 'CHECK_ERROR'
    });
  }
});

// GET /api/claim/stats - Get claiming statistics
router.get('/stats', async (req, res) => {
  try {
    const [totalClaimed] = await db
      .select({ count: count() })
      .from(fsnIdentity);

    const recentClaims = await db
      .select({
        fsnName: fsnIdentity.fsnName,
        walletType: fsnIdentity.walletType,
        claimedAt: fsnIdentity.claimedAt
      })
      .from(fsnIdentity)
      .orderBy(fsnIdentity.claimedAt)
      .limit(10);

    res.json({
      totalClaimed: totalClaimed.count,
      recentClaims: recentClaims.map(claim => ({
        name: claim.fsnName,
        walletType: claim.walletType,
        claimedAt: claim.claimedAt
      }))
    });

  } catch (error) {
    console.error('FSN stats error:', error);
    res.status(500).json({
      error: 'Error fetching claim statistics',
      code: 'STATS_ERROR'
    });
  }
});

export default router;