// FSN Phase 0 - Leaderboard route
import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db';
import { users, signals, pulseState, xpEvents, fsnIdentity } from '../../shared/schema';
import { desc, eq, count, sql } from 'drizzle-orm';

const router = Router();

// Validation schema for leaderboard queries
const leaderboardQuerySchema = z.object({
  limit: z.coerce.number().min(1).max(100).default(50),
  offset: z.coerce.number().min(0).default(0),
  type: z.enum(['xp', 'streak', 'pulse', 'signals']).default('xp')
});

// GET /api/leaderboard - Return top active users by different metrics
router.get('/', async (req, res) => {
  try {
    // Validate query parameters
    const result = leaderboardQuerySchema.safeParse(req.query);
    if (!result.success) {
      return res.status(400).json({
        error: 'Invalid query parameters',
        details: result.error.issues,
        code: 'VALIDATION_ERROR'
      });
    }

    const { limit, offset, type } = result.data;

    let leaderboard;
    let totalCount;

    switch (type) {
      case 'xp':
        // XP Leaderboard
        leaderboard = await db
          .select({
            rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${users.xpMirror} DESC)`,
            address: users.address,
            name: users.name,
            xpMirror: users.xpMirror,
            streak: users.streak,
            lastSeen: users.lastSeen
          })
          .from(users)
          .where(sql`${users.xpMirror} > 0`)
          .orderBy(desc(users.xpMirror))
          .limit(limit)
          .offset(offset);

        const [xpTotal] = await db
          .select({ count: count() })
          .from(users)
          .where(sql`${users.xpMirror} > 0`);
        totalCount = xpTotal.count;
        break;

      case 'streak':
        // Streak Leaderboard
        leaderboard = await db
          .select({
            rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${users.streak} DESC, ${users.lastSeen} DESC)`,
            address: users.address,
            name: users.name,
            xpMirror: users.xpMirror,
            streak: users.streak,
            lastSeen: users.lastSeen
          })
          .from(users)
          .where(sql`${users.streak} > 0`)
          .orderBy(desc(users.streak), desc(users.lastSeen))
          .limit(limit)
          .offset(offset);

        const [streakTotal] = await db
          .select({ count: count() })
          .from(users)
          .where(sql`${users.streak} > 0`);
        totalCount = streakTotal.count;
        break;

      case 'pulse':
        // Pulse Leaderboard (by total charges and streak)
        leaderboard = await db
          .select({
            rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${pulseState.totalCharges} DESC, ${pulseState.streakDays} DESC)`,
            address: users.address,
            name: users.name,
            xpMirror: users.xpMirror,
            pulseLevel: pulseState.pulseLevel,
            streakDays: pulseState.streakDays,
            totalCharges: pulseState.totalCharges,
            lastChargeAt: pulseState.lastChargeAt
          })
          .from(users)
          .innerJoin(pulseState, eq(users.address, pulseState.userId))
          .where(sql`${pulseState.totalCharges} > 0`)
          .orderBy(desc(pulseState.totalCharges), desc(pulseState.streakDays))
          .limit(limit)
          .offset(offset);

        const [pulseTotal] = await db
          .select({ count: count() })
          .from(pulseState)
          .where(sql`${pulseState.totalCharges} > 0`);
        totalCount = pulseTotal.count;
        break;

      case 'signals':
        // Signal Leaderboard (by total activations)
        leaderboard = await db
          .select({
            rank: sql<number>`ROW_NUMBER() OVER (ORDER BY ${signals.totalActivations} DESC, ${signals.activatedAt} DESC NULLS LAST)`,
            address: users.address,
            name: users.name,
            xpMirror: users.xpMirror,
            totalActivations: signals.totalActivations,
            active: signals.active,
            activatedAt: signals.activatedAt
          })
          .from(users)
          .innerJoin(signals, eq(users.address, signals.userId))
          .where(sql`${signals.totalActivations} > 0`)
          .orderBy(desc(signals.totalActivations), sql`${signals.activatedAt} DESC NULLS LAST`)
          .limit(limit)
          .offset(offset);

        const [signalsTotal] = await db
          .select({ count: count() })
          .from(signals)
          .where(sql`${signals.totalActivations} > 0`);
        totalCount = signalsTotal.count;
        break;
    }

    // Get global statistics
    const [totalUsers] = await db.select({ count: count() }).from(users);
    const [totalIdentities] = await db.select({ count: count() }).from(fsnIdentity);
    const [activeSignals] = await db.select({ count: count() }).from(signals).where(eq(signals.active, true));
    const [totalXpAwarded] = await db.select({ 
      total: sql<number>`COALESCE(SUM(${xpEvents.points}), 0)` 
    }).from(xpEvents);

    // Privacy: Truncate addresses for public display
    const publicLeaderboard = leaderboard.map(entry => ({
      ...entry,
      address: entry.address.slice(0, 6) + '...' + entry.address.slice(-4)
    }));

    res.json({
      success: true,
      type,
      leaderboard: publicLeaderboard,
      pagination: {
        limit,
        offset,
        total: totalCount,
        hasNext: offset + limit < totalCount
      },
      globalStats: {
        totalUsers: totalUsers.count,
        totalIdentities: totalIdentities.count,
        activeSignals: activeSignals.count,
        totalXpAwarded: totalXpAwarded.total
      }
    });

  } catch (error) {
    console.error('Leaderboard error:', error);
    res.status(500).json({
      error: 'Error fetching leaderboard data',
      code: 'LEADERBOARD_ERROR'
    });
  }
});

// GET /api/leaderboard/user/:address - Get user's ranking across all leaderboards
router.get('/user/:address', async (req, res) => {
  try {
    const walletAddress = req.params.address;

    if (!/^0x[a-fA-F0-9]{40}$/.test(walletAddress)) {
      return res.status(400).json({
        error: 'Invalid wallet address',
        code: 'INVALID_ADDRESS'
      });
    }

    // Get user data
    const user = await db
      .select()
      .from(users)
      .where(eq(users.address, walletAddress))
      .limit(1);

    if (!user.length) {
      return res.status(404).json({
        error: 'User not found',
        code: 'USER_NOT_FOUND'
      });
    }

    // Get user's XP rank
    const xpRankResult = await db.execute(sql`
      SELECT rank FROM (
        SELECT address, ROW_NUMBER() OVER (ORDER BY xp_mirror DESC) as rank
        FROM users 
        WHERE xp_mirror > 0
      ) ranked 
      WHERE address = ${walletAddress}
    `);
    const xpRank = xpRankResult.rows[0]?.rank || null;

    // Get user's streak rank
    const streakRankResult = await db.execute(sql`
      SELECT rank FROM (
        SELECT address, ROW_NUMBER() OVER (ORDER BY streak DESC, last_seen DESC) as rank
        FROM users 
        WHERE streak > 0
      ) ranked 
      WHERE address = ${walletAddress}
    `);
    const streakRank = streakRankResult.rows[0]?.rank || null;

    // Get user's pulse data and rank
    const pulseData = await db
      .select()
      .from(pulseState)
      .where(eq(pulseState.userId, walletAddress))
      .limit(1);

    let pulseRank = null;
    if (pulseData.length > 0) {
      const pulseRankResult = await db.execute(sql`
        SELECT rank FROM (
          SELECT user_id, ROW_NUMBER() OVER (ORDER BY total_charges DESC, streak_days DESC) as rank
          FROM pulse_state 
          WHERE total_charges > 0
        ) ranked 
        WHERE user_id = ${walletAddress}
      `);
      pulseRank = pulseRankResult.rows[0]?.rank || null;
    }

    // Get user's signal data and rank
    const signalData = await db
      .select()
      .from(signals)
      .where(eq(signals.userId, walletAddress))
      .limit(1);

    let signalRank = null;
    if (signalData.length > 0) {
      const signalRankResult = await db.execute(sql`
        SELECT rank FROM (
          SELECT user_id, ROW_NUMBER() OVER (ORDER BY total_activations DESC, activated_at DESC NULLS LAST) as rank
          FROM signals 
          WHERE total_activations > 0
        ) ranked 
        WHERE user_id = ${walletAddress}
      `);
      signalRank = signalRankResult.rows[0]?.rank || null;
    }

    res.json({
      success: true,
      user: user[0],
      rankings: {
        xp: {
          rank: xpRank,
          value: user[0].xpMirror,
          total: user[0].xpMirror
        },
        streak: {
          rank: streakRank,
          value: user[0].streak,
          current: user[0].streak
        },
        pulse: pulseData.length > 0 ? {
          rank: pulseRank,
          value: pulseData[0].totalCharges,
          streakDays: pulseData[0].streakDays,
          pulseLevel: pulseData[0].pulseLevel,
          lastChargeAt: pulseData[0].lastChargeAt
        } : null,
        signal: signalData.length > 0 ? {
          rank: signalRank,
          value: signalData[0].totalActivations,
          active: signalData[0].active,
          activatedAt: signalData[0].activatedAt
        } : null
      }
    });

  } catch (error) {
    console.error('User ranking error:', error);
    res.status(500).json({
      error: 'Error fetching user ranking data',
      code: 'USER_RANKING_ERROR'
    });
  }
});

// GET /api/leaderboard/stats - Get overall platform statistics
router.get('/stats', async (req, res) => {
  try {
    // Total users and identities
    const [totalUsers] = await db.select({ count: count() }).from(users);
    const [totalIdentities] = await db.select({ count: count() }).from(fsnIdentity);

    // XP statistics
    const [totalXP] = await db.select({ 
      total: sql<number>`COALESCE(SUM(${xpEvents.points}), 0)` 
    }).from(xpEvents);

    const [avgXP] = await db.select({ 
      avg: sql<number>`COALESCE(AVG(${users.xpMirror}), 0)` 
    }).from(users).where(sql`${users.xpMirror} > 0`);

    // Pulse statistics
    const [totalPulseCharges] = await db.select({ 
      total: sql<number>`COALESCE(SUM(${pulseState.totalCharges}), 0)` 
    }).from(pulseState);

    const [avgStreak] = await db.select({ 
      avg: sql<number>`COALESCE(AVG(${pulseState.streakDays}), 0)` 
    }).from(pulseState).where(sql`${pulseState.streakDays} > 0`);

    const [longestStreak] = await db.select({ 
      max: sql<number>`COALESCE(MAX(${pulseState.streakDays}), 0)` 
    }).from(pulseState);

    // Signal statistics
    const [activeSignals] = await db.select({ count: count() }).from(signals).where(eq(signals.active, true));
    const [totalSignalActivations] = await db.select({ 
      total: sql<number>`COALESCE(SUM(${signals.totalActivations}), 0)` 
    }).from(signals);

    const SIGNAL_CAP = parseInt(process.env.SIGNAL_CAP || '100000', 10);

    // Recent activity (last 24 hours)
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const [recentXPEvents] = await db.select({ count: count() })
      .from(xpEvents)
      .where(sql`${xpEvents.createdAt} > ${twentyFourHoursAgo}`);

    const [recentPulseCharges] = await db.select({ count: count() })
      .from(pulseState)
      .where(sql`${pulseState.lastChargeAt} > ${twentyFourHoursAgo}`);

    res.json({
      success: true,
      platform: {
        totalUsers: totalUsers.count,
        totalIdentities: totalIdentities.count,
        totalXP: totalXP.total,
        averageXP: Math.round(avgXP.avg)
      },
      pulse: {
        totalCharges: totalPulseCharges.total,
        averageStreak: Math.round(avgStreak.avg * 10) / 10, // Round to 1 decimal
        longestStreak: longestStreak.max
      },
      signals: {
        activeSignals: activeSignals.count,
        signalCap: SIGNAL_CAP,
        utilizationPercent: Math.round((activeSignals.count / SIGNAL_CAP) * 100),
        totalActivations: totalSignalActivations.total
      },
      activity24h: {
        xpEvents: recentXPEvents.count,
        pulseCharges: recentPulseCharges.count
      }
    });

  } catch (error) {
    console.error('Platform stats error:', error);
    res.status(500).json({
      error: 'Error fetching platform statistics',
      code: 'STATS_ERROR'
    });
  }
});

export default router;