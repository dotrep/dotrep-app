// FSN Phase 0 - Pulse charging route
import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db';
import { pulseState, users, xpEvents, abuseLog } from '../../shared/schema';
import { eq } from 'drizzle-orm';
import crypto from 'crypto';

const router = Router();

// Feature flag check
const ENABLE_PULSE = process.env.ENABLE_PULSE === 'true';

// Validation schema for pulse charge
const pulseChargeSchema = z.object({
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/, 'Invalid wallet address'),
  deviceId: z.string().optional(),
  userAgent: z.string().optional()
});

// POST /api/pulse/charge - Daily charge, update streak + XP
router.post('/charge', async (req, res) => {
  try {
    // Feature flag check
    if (!ENABLE_PULSE) {
      return res.status(503).json({ 
        error: 'Pulse charging is currently disabled',
        code: 'PULSE_DISABLED' 
      });
    }

    // Validate request body
    const result = pulseChargeSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({
        error: 'Invalid request data',
        details: result.error.issues,
        code: 'VALIDATION_ERROR'
      });
    }

    const { walletAddress, deviceId, userAgent } = result.data;

    // Log abuse prevention data
    const ipHash = crypto.createHash('sha256')
      .update(req.ip + 'salt_for_privacy')
      .digest('hex');

    // Check if user exists and has FSN identity
    const user = await db
      .select()
      .from(users)
      .where(eq(users.address, walletAddress))
      .limit(1);

    if (!user.length) {
      return res.status(404).json({
        error: 'User not found. Please claim your FSN identity first.',
        code: 'USER_NOT_FOUND'
      });
    }

    // Get or create pulse state
    let pulse = await db
      .select()
      .from(pulseState)
      .where(eq(pulseState.userId, walletAddress))
      .limit(1);

    if (!pulse.length) {
      // Create initial pulse state
      const newPulse = await db.insert(pulseState).values({
        userId: walletAddress,
        lastChargeAt: null,
        streakDays: 0,
        pulseLevel: 1,
        totalCharges: 0
      }).returning();
      pulse = newPulse;
    }

    const currentPulse = pulse[0];
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // Check if already charged today
    if (currentPulse.lastChargeAt) {
      const lastChargeDate = new Date(currentPulse.lastChargeAt);
      const lastChargeDay = new Date(lastChargeDate.getFullYear(), lastChargeDate.getMonth(), lastChargeDate.getDate());
      
      if (lastChargeDay.getTime() === today.getTime()) {
        // Calculate time until next charge
        const nextChargeTime = new Date(today);
        nextChargeTime.setDate(nextChargeTime.getDate() + 1);
        const hoursUntilNext = Math.ceil((nextChargeTime.getTime() - now.getTime()) / (1000 * 60 * 60));
        
        // Log repeated charge attempt
        await db.insert(abuseLog).values({
          userId: walletAddress,
          deviceId: deviceId || null,
          ipHash,
          event: 'duplicate_pulse_charge',
          metadata: { lastChargeAt: currentPulse.lastChargeAt }
        });

        return res.status(429).json({
          error: 'Pulse already charged today',
          lastChargeAt: currentPulse.lastChargeAt,
          nextChargeAvailable: nextChargeTime,
          hoursUntilNext,
          code: 'ALREADY_CHARGED_TODAY'
        });
      }
    }

    // Calculate streak
    let newStreak = 1;
    if (currentPulse.lastChargeAt) {
      const lastChargeDate = new Date(currentPulse.lastChargeAt);
      const lastChargeDay = new Date(lastChargeDate.getFullYear(), lastChargeDate.getMonth(), lastChargeDate.getDate());
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      
      if (lastChargeDay.getTime() === yesterday.getTime()) {
        // Consecutive day - continue streak
        newStreak = currentPulse.streakDays + 1;
      } else {
        // Streak broken or first charge
        newStreak = 1;
      }
    }

    // Calculate XP reward
    let xpReward = 10; // Base XP for pulse charge
    
    // Streak bonuses
    if (newStreak >= 7) xpReward += 20;  // Weekly streak bonus
    if (newStreak >= 30) xpReward += 50; // Monthly streak bonus
    if (newStreak >= 100) xpReward += 100; // Century streak bonus

    // Update pulse state
    const updatedPulse = await db
      .update(pulseState)
      .set({
        lastChargeAt: now,
        streakDays: newStreak,
        pulseLevel: Math.min(10, Math.floor(newStreak / 7) + 1), // Max level 10
        totalCharges: currentPulse.totalCharges + 1
      })
      .where(eq(pulseState.userId, walletAddress))
      .returning();

    // Award XP
    await db.insert(xpEvents).values({
      userId: walletAddress,
      type: 'pulse_charge',
      points: xpReward,
      metadata: { 
        streakDays: newStreak,
        pulseLevel: updatedPulse[0].pulseLevel,
        totalCharges: updatedPulse[0].totalCharges
      }
    });

    // Update user streak and XP mirror
    const currentXP = user[0].xpMirror + xpReward;
    await db
      .update(users)
      .set({ 
        streak: newStreak,
        xpMirror: currentXP,
        lastSeen: now
      })
      .where(eq(users.address, walletAddress));

    // Log successful charge
    await db.insert(abuseLog).values({
      userId: walletAddress,
      deviceId: deviceId || null,
      ipHash,
      event: 'successful_pulse_charge',
      metadata: { 
        streakDays: newStreak,
        xpAwarded: xpReward,
        pulseLevel: updatedPulse[0].pulseLevel
      }
    });

    // Return success response
    res.json({
      success: true,
      pulseState: updatedPulse[0],
      xpAwarded: xpReward,
      totalXP: currentXP,
      streakDays: newStreak,
      pulseLevel: updatedPulse[0].pulseLevel,
      message: `Pulse charged! +${xpReward} XP • ${newStreak} day streak`
    });

  } catch (error) {
    console.error('Pulse charge error:', error);
    res.status(500).json({
      error: 'Internal server error during pulse charge',
      code: 'CHARGE_ERROR'
    });
  }
});

// GET /api/pulse/status/:address - Get pulse status for user
router.get('/status/:address', async (req, res) => {
  try {
    const walletAddress = req.params.address;

    if (!/^0x[a-fA-F0-9]{40}$/.test(walletAddress)) {
      return res.status(400).json({
        error: 'Invalid wallet address',
        code: 'INVALID_ADDRESS'
      });
    }

    // Get pulse state
    const pulse = await db
      .select()
      .from(pulseState)
      .where(eq(pulseState.userId, walletAddress))
      .limit(1);

    if (!pulse.length) {
      return res.json({
        exists: false,
        canChargeToday: true,
        streakDays: 0,
        pulseLevel: 1,
        totalCharges: 0
      });
    }

    const currentPulse = pulse[0];
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Check if can charge today
    let canChargeToday = true;
    let nextChargeTime = null;

    if (currentPulse.lastChargeAt) {
      const lastChargeDate = new Date(currentPulse.lastChargeAt);
      const lastChargeDay = new Date(lastChargeDate.getFullYear(), lastChargeDate.getMonth(), lastChargeDate.getDate());
      
      if (lastChargeDay.getTime() === today.getTime()) {
        canChargeToday = false;
        nextChargeTime = new Date(today);
        nextChargeTime.setDate(nextChargeTime.getDate() + 1);
      }
    }

    res.json({
      exists: true,
      pulseState: currentPulse,
      canChargeToday,
      nextChargeTime,
      hoursUntilNext: nextChargeTime ? Math.ceil((nextChargeTime.getTime() - now.getTime()) / (1000 * 60 * 60)) : 0
    });

  } catch (error) {
    console.error('Pulse status error:', error);
    res.status(500).json({
      error: 'Error fetching pulse status',
      code: 'STATUS_ERROR'
    });
  }
});

export default router;