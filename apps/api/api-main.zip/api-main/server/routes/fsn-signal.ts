// FSN Phase 0 - Signal beam toggle route
import { Router } from 'express';
import { z } from 'zod';
import { db } from '../db';
import { signals, users, xpEvents, abuseLog } from '../../shared/schema';
import { eq, count, and, sql } from 'drizzle-orm';
import crypto from 'crypto';

const router = Router();

// Feature flag check
const ENABLE_SIGNAL = process.env.ENABLE_SIGNAL === 'true';
const SIGNAL_CAP = parseInt(process.env.SIGNAL_CAP || '100000', 10);

// Validation schema for signal toggle
const signalToggleSchema = z.object({
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/, 'Invalid wallet address'),
  activate: z.boolean(),
  deviceId: z.string().optional(),
  userAgent: z.string().optional()
});

// POST /api/signal/toggle - Toggle signal beam with global cap enforcement
router.post('/toggle', async (req, res) => {
  try {
    // Feature flag check
    if (!ENABLE_SIGNAL) {
      return res.status(503).json({ 
        error: 'Signal beam is currently disabled',
        code: 'SIGNAL_DISABLED' 
      });
    }

    // Validate request body
    const result = signalToggleSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({
        error: 'Invalid request data',
        details: result.error.issues,
        code: 'VALIDATION_ERROR'
      });
    }

    const { walletAddress, activate, deviceId, userAgent } = result.data;

    // Log abuse prevention data
    const ipHash = crypto.createHash('sha256')
      .update(req.ip + 'salt_for_privacy')
      .digest('hex');

    // Check if user exists and has FSN identity
    const user = await db
      .select()
      .from(users)
      .where(eq(users.address, walletAddress))
      .limit(1);

    if (!user.length) {
      return res.status(404).json({
        error: 'User not found. Please claim your FSN identity first.',
        code: 'USER_NOT_FOUND'
      });
    }

    // Get current active signal count
    const [activeCount] = await db
      .select({ count: count() })
      .from(signals)
      .where(eq(signals.active, true));

    // Get or create signal state
    let signal = await db
      .select()
      .from(signals)
      .where(eq(signals.userId, walletAddress))
      .limit(1);

    if (!signal.length) {
      // Create initial signal state
      const newSignal = await db.insert(signals).values({
        userId: walletAddress,
        active: false,
        activatedAt: null,
        totalActivations: 0
      }).returning();
      signal = newSignal;
    }

    const currentSignal = signal[0];

    // If trying to activate and already active, return current state
    if (activate && currentSignal.active) {
      return res.json({
        success: true,
        signal: currentSignal,
        message: 'Signal beam already active',
        globalStats: {
          activeSignals: activeCount.count,
          signalCap: SIGNAL_CAP,
          availableSlots: Math.max(0, SIGNAL_CAP - activeCount.count)
        }
      });
    }

    // If trying to deactivate and already inactive, return current state  
    if (!activate && !currentSignal.active) {
      return res.json({
        success: true,
        signal: currentSignal,
        message: 'Signal beam already inactive',
        globalStats: {
          activeSignals: activeCount.count,
          signalCap: SIGNAL_CAP,
          availableSlots: Math.max(0, SIGNAL_CAP - activeCount.count)
        }
      });
    }

    // Check global signal cap when activating
    if (activate && activeCount.count >= SIGNAL_CAP) {
      // Log cap reached attempt
      await db.insert(abuseLog).values({
        userId: walletAddress,
        deviceId: deviceId || null,
        ipHash,
        event: 'signal_cap_reached',
        metadata: { 
          activeCount: activeCount.count,
          signalCap: SIGNAL_CAP
        }
      });

      return res.status(429).json({
        error: 'Global signal capacity reached',
        activeSignals: activeCount.count,
        signalCap: SIGNAL_CAP,
        message: 'The signal network is at maximum capacity. Try again later.',
        code: 'SIGNAL_CAP_REACHED'
      });
    }

    const now = new Date();
    
    // Update signal state
    const updatedSignal = await db
      .update(signals)
      .set({
        active: activate,
        activatedAt: activate ? now : currentSignal.activatedAt,
        totalActivations: activate ? currentSignal.totalActivations + 1 : currentSignal.totalActivations
      })
      .where(eq(signals.userId, walletAddress))
      .returning();

    // Award XP for signal activation
    let xpReward = 0;
    if (activate) {
      xpReward = 15; // Base XP for signal activation
      
      // Milestone bonuses
      const totalActivations = updatedSignal[0].totalActivations;
      if (totalActivations === 10) xpReward += 25;   // First 10 activations
      if (totalActivations === 50) xpReward += 50;   // 50 activations milestone
      if (totalActivations === 100) xpReward += 100; // 100 activations milestone

      await db.insert(xpEvents).values({
        userId: walletAddress,
        type: 'signal_activate',
        points: xpReward,
        metadata: { 
          totalActivations,
          globalActiveCount: activeCount.count + 1
        }
      });

      // Update user XP mirror
      const currentXP = user[0].xpMirror + xpReward;
      await db
        .update(users)
        .set({ 
          xpMirror: currentXP,
          lastSeen: now
        })
        .where(eq(users.address, walletAddress));
    } else {
      // Award small XP for deactivation (making room for others)
      xpReward = 5;
      
      await db.insert(xpEvents).values({
        userId: walletAddress,
        type: 'signal_deactivate',
        points: xpReward,
        metadata: { 
          totalActivations: updatedSignal[0].totalActivations,
          globalActiveCount: activeCount.count - 1
        }
      });

      // Update user XP mirror
      const currentXP = user[0].xpMirror + xpReward;
      await db
        .update(users)
        .set({ 
          xpMirror: currentXP,
          lastSeen: now
        })
        .where(eq(users.address, walletAddress));
    }

    // Log successful signal toggle
    await db.insert(abuseLog).values({
      userId: walletAddress,
      deviceId: deviceId || null,
      ipHash,
      event: activate ? 'signal_activated' : 'signal_deactivated',
      metadata: { 
        totalActivations: updatedSignal[0].totalActivations,
        xpAwarded: xpReward,
        globalActiveCount: activate ? activeCount.count + 1 : activeCount.count - 1
      }
    });

    // Get updated global stats
    const newActiveCount = activate ? activeCount.count + 1 : activeCount.count - 1;

    // Return success response
    res.json({
      success: true,
      signal: updatedSignal[0],
      xpAwarded: xpReward,
      action: activate ? 'activated' : 'deactivated',
      message: activate 
        ? `Signal beam activated! +${xpReward} XP`
        : `Signal beam deactivated. +${xpReward} XP for making room.`,
      globalStats: {
        activeSignals: newActiveCount,
        signalCap: SIGNAL_CAP,
        availableSlots: Math.max(0, SIGNAL_CAP - newActiveCount),
        utilizationPercent: Math.round((newActiveCount / SIGNAL_CAP) * 100)
      }
    });

  } catch (error) {
    console.error('Signal toggle error:', error);
    res.status(500).json({
      error: 'Internal server error during signal toggle',
      code: 'SIGNAL_ERROR'
    });
  }
});

// GET /api/signal/status/:address - Get signal status for user
router.get('/status/:address', async (req, res) => {
  try {
    const walletAddress = req.params.address;

    if (!/^0x[a-fA-F0-9]{40}$/.test(walletAddress)) {
      return res.status(400).json({
        error: 'Invalid wallet address',
        code: 'INVALID_ADDRESS'
      });
    }

    // Get signal state
    const signal = await db
      .select()
      .from(signals)
      .where(eq(signals.userId, walletAddress))
      .limit(1);

    // Get global active count
    const [activeCount] = await db
      .select({ count: count() })
      .from(signals)
      .where(eq(signals.active, true));

    const globalStats = {
      activeSignals: activeCount.count,
      signalCap: SIGNAL_CAP,
      availableSlots: Math.max(0, SIGNAL_CAP - activeCount.count),
      utilizationPercent: Math.round((activeCount.count / SIGNAL_CAP) * 100),
      isCapReached: activeCount.count >= SIGNAL_CAP
    };

    if (!signal.length) {
      return res.json({
        exists: false,
        active: false,
        totalActivations: 0,
        canActivate: !globalStats.isCapReached,
        globalStats
      });
    }

    const currentSignal = signal[0];

    res.json({
      exists: true,
      signal: currentSignal,
      canActivate: !currentSignal.active && !globalStats.isCapReached,
      canDeactivate: currentSignal.active,
      globalStats
    });

  } catch (error) {
    console.error('Signal status error:', error);
    res.status(500).json({
      error: 'Error fetching signal status',
      code: 'STATUS_ERROR'
    });
  }
});

// GET /api/signal/network - Get global signal network status
router.get('/network', async (req, res) => {
  try {
    // Get active signals count
    const [activeCount] = await db
      .select({ count: count() })
      .from(signals)
      .where(eq(signals.active, true));

    // Get recent activations
    const recentActivations = await db
      .select({
        userId: signals.userId,
        activatedAt: signals.activatedAt,
        totalActivations: signals.totalActivations
      })
      .from(signals)
      .where(eq(signals.active, true))
      .orderBy(sql`${signals.activatedAt} DESC NULLS LAST`)
      .limit(10);

    // Get top signalers
    const topSignalers = await db
      .select({
        userId: signals.userId,
        totalActivations: signals.totalActivations,
        active: signals.active
      })
      .from(signals)
      .orderBy(sql`${signals.totalActivations} DESC`)
      .limit(10);

    const globalStats = {
      activeSignals: activeCount.count,
      signalCap: SIGNAL_CAP,
      availableSlots: Math.max(0, SIGNAL_CAP - activeCount.count),
      utilizationPercent: Math.round((activeCount.count / SIGNAL_CAP) * 100),
      isCapReached: activeCount.count >= SIGNAL_CAP
    };

    res.json({
      globalStats,
      recentActivations: recentActivations.map(activation => ({
        userId: activation.userId.slice(0, 6) + '...' + activation.userId.slice(-4), // Privacy
        activatedAt: activation.activatedAt,
        totalActivations: activation.totalActivations
      })),
      topSignalers: topSignalers.map((signaler, index) => ({
        rank: index + 1,
        userId: signaler.userId.slice(0, 6) + '...' + signaler.userId.slice(-4), // Privacy
        totalActivations: signaler.totalActivations,
        currentlyActive: signaler.active
      }))
    });

  } catch (error) {
    console.error('Signal network error:', error);
    res.status(500).json({
      error: 'Error fetching signal network status',
      code: 'NETWORK_ERROR'
    });
  }
});

export default router;