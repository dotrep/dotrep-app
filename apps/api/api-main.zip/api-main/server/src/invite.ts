import { type Request, type Response } from "express";
import { SignJWT, jwtVerify } from "jose";
import { randomBytes } from "crypto";

const JWT_SECRET = process.env.JWT_SECRET;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
const BASE_URL = process.env.BASE_URL || 'http://localhost:5000';
const INVITE_TTL_HOURS = parseInt(process.env.INVITE_TTL_HOURS || '72');

export async function createInviteLinks(req: Request, res: Response) {
  try {
    // Check authorization
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ') || authHeader.slice(7) !== ADMIN_TOKEN) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    if (!JWT_SECRET) {
      return res.status(500).json({ error: 'Server configuration error' });
    }

    const { count = 10, hours = INVITE_TTL_HOURS } = req.body;
    const links = [];
    const secret = new TextEncoder().encode(JWT_SECRET);

    for (let i = 0; i < count; i++) {
      // Generate random 16-byte hex string for jti
      const jti = randomBytes(16).toString('hex');
      
      // Create JWT with invite payload
      const token = await new SignJWT({
        sub: 'invite',
        jti,
      })
        .setProtectedHeader({ alg: 'HS256' })
        .setExpirationTime(`${hours}h`)
        .setIssuedAt()
        .sign(secret);

      // Build invite URL
      const inviteUrl = `${BASE_URL}/api/invite/accept?token=${token}`;
      links.push(inviteUrl);
    }

    res.json({ links });
  } catch (error) {
    console.error('Error creating invite links:', error);
    res.status(500).json({ error: 'Failed to create invite links' });
  }
}

export async function acceptInvite(req: Request, res: Response) {
  try {
    const token = req.query.token as string;

    if (!token || !JWT_SECRET) {
      return res.status(404).json({ error: 'Not found' });
    }

    const secret = new TextEncoder().encode(JWT_SECRET);
    const { payload } = await jwtVerify(token, secret);

    // Verify it's an invite token
    if (payload.sub !== 'invite') {
      return res.status(404).json({ error: 'Not found' });
    }

    // Calculate remaining token lifetime for cookie maxAge
    const exp = payload.exp as number;
    const now = Math.floor(Date.now() / 1000);
    const remainingSeconds = exp - now;

    if (remainingSeconds <= 0) {
      return res.status(404).json({ error: 'Not found' });
    }

    // Set the fsn_beta cookie with the invite token
    res.cookie('fsn_beta', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: remainingSeconds * 1000, // Express expects milliseconds
    });

    // Redirect to /connect
    res.redirect('/connect');
  } catch (error) {
    // Don't leak token validation errors
    res.status(404).json({ error: 'Not found' });
  }
}