/**
 * System Health Monitoring
 * Lightweight health checks for core dependencies
 */

import { db } from '../db';
import { metrics } from './metrics';

export interface HealthStatus {
  ok: boolean;
  uptime: number;
  db: 'ok' | 'down';
  redis?: 'ok' | 'down';
}

/**
 * Check database connectivity
 */
async function checkDatabase(): Promise<'ok' | 'down'> {
  try {
    // Simple query to test connection
    await db.execute('SELECT 1');
    return 'ok';
  } catch (error) {
    console.error('Health check - DB failed:', error);
    return 'down';
  }
}

/**
 * Check Redis connectivity (optional)
 * Note: Add Redis client import if used in future
 */
async function checkRedis(): Promise<'ok' | 'down'> {
  // Placeholder for Redis health check
  // return redis?.ping() ? 'ok' : 'down';
  return 'ok'; // Skip for now
}

/**
 * Get comprehensive health status
 */
export async function getHealthStatus(): Promise<HealthStatus> {
  const uptime = Math.floor(process.uptime());
  
  try {
    const [dbStatus, redisStatus] = await Promise.allSettled([
      checkDatabase(),
      checkRedis()
    ]);

    return {
      ok: dbStatus.status === 'fulfilled' && dbStatus.value === 'ok',
      uptime,
      db: dbStatus.status === 'fulfilled' ? dbStatus.value : 'down',
      redis: redisStatus.status === 'fulfilled' ? redisStatus.value : 'down'
    };
  } catch (error) {
    console.error('Health check failed:', error);
    return {
      ok: false,
      uptime,
      db: 'down'
    };
  }
}

/**
 * Express handler for /health endpoint
 */
export async function healthHandler(req: any, res: any): Promise<void> {
  try {
    const health = await getHealthStatus();
    const status = health.ok ? 200 : 503;
    
    res.status(status).json(health);
  } catch (error) {
    res.status(500).json({
      ok: false,
      error: 'Health check failed',
      uptime: Math.floor(process.uptime()),
      db: 'down'
    });
  }
}

/**
 * Express handler for /metrics endpoint
 */
export function metricsHandler(req: any, res: any): void {
  try {
    const data = metrics.getMetrics();
    res.json(data);
  } catch (error) {
    res.status(500).json({
      error: 'Metrics collection failed'
    });
  }
}