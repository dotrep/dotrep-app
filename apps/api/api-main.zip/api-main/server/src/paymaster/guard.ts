/**
 * Paymaster Safety Guard System
 * Implements spend caps, QPS limits, and safety checks for gasless transactions
 */

import { config } from '../config';
import { metrics } from '../metrics';

interface SpendTracker {
  date: string; // YYYY-MM-DD format
  spentCents: number;
  transactionCount: number;
}

interface QpsTracker {
  secondStart: number;
  requestCount: number;
}

/**
 * Paymaster safety guard with spend and rate limiting
 */
class PaymasterGuard {
  private dailySpend = new Map<string, SpendTracker>();
  private qpsTracker = new Map<string, QpsTracker>();
  
  // Cleanup old entries periodically
  private lastCleanup = 0;
  private readonly CLEANUP_INTERVAL = 3600 * 1000; // 1 hour

  /**
   * Check if paymaster operation is allowed for wallet
   */
  async checkAllowed(walletAddress: string, estimatedCostCents: number = 50): Promise<{
    allowed: boolean;
    reason?: string;
    remainingBudgetCents?: number;
    qpsLimitRemaining?: number;
  }> {
    // Cleanup old data periodically
    this.periodicCleanup();

    // Check feature flag
    if (!config.ENABLE_PAYMASTER) {
      return {
        allowed: false,
        reason: 'Paymaster feature is disabled'
      };
    }

    // Check daily spend limit
    const spendCheck = this.checkDailySpendLimit(walletAddress, estimatedCostCents);
    if (!spendCheck.allowed) {
      return spendCheck;
    }

    // Check QPS limit
    const qpsCheck = this.checkQpsLimit(walletAddress);
    if (!qpsCheck.allowed) {
      return qpsCheck;
    }

    return {
      allowed: true,
      remainingBudgetCents: spendCheck.remainingBudgetCents,
      qpsLimitRemaining: qpsCheck.qpsLimitRemaining
    };
  }

  /**
   * Record successful paymaster operation
   */
  recordSuccess(walletAddress: string, actualCostCents: number): void {
    const today = this.getTodayString();
    const key = `${walletAddress}_${today}`;

    if (!this.dailySpend.has(key)) {
      this.dailySpend.set(key, {
        date: today,
        spentCents: 0,
        transactionCount: 0
      });
    }

    const tracker = this.dailySpend.get(key)!;
    tracker.spentCents += actualCostCents;
    tracker.transactionCount++;

    // Update metrics
    metrics.recordPaymaster(true, (tracker.spentCents / config.PAYMASTER_DAILY_CAP) * 100);
  }

  /**
   * Record failed paymaster operation
   */
  recordFailure(walletAddress: string, reason: string): void {
    metrics.recordPaymaster(false, 0);
  }

  /**
   * Get spending statistics for wallet
   */
  getWalletStats(walletAddress: string): {
    todaySpentCents: number;
    todayTransactions: number;
    remainingBudgetCents: number;
    budgetUtilizationPct: number;
  } {
    const today = this.getTodayString();
    const key = `${walletAddress}_${today}`;
    const tracker = this.dailySpend.get(key);

    const spentCents = tracker?.spentCents || 0;
    const transactions = tracker?.transactionCount || 0;
    const remainingCents = Math.max(0, config.PAYMASTER_DAILY_CAP - spentCents);
    const utilizationPct = (spentCents / config.PAYMASTER_DAILY_CAP) * 100;

    return {
      todaySpentCents: spentCents,
      todayTransactions: transactions,
      remainingBudgetCents: remainingCents,
      budgetUtilizationPct: Math.min(100, utilizationPct)
    };
  }

  /**
   * Check daily spending limit for wallet
   */
  private checkDailySpendLimit(walletAddress: string, estimatedCostCents: number): {
    allowed: boolean;
    reason?: string;
    remainingBudgetCents: number;
  } {
    const today = this.getTodayString();
    const key = `${walletAddress}_${today}`;
    const tracker = this.dailySpend.get(key);
    
    const currentSpentCents = tracker?.spentCents || 0;
    const remainingBudgetCents = Math.max(0, config.PAYMASTER_DAILY_CAP - currentSpentCents);

    if (currentSpentCents + estimatedCostCents > config.PAYMASTER_DAILY_CAP) {
      return {
        allowed: false,
        reason: `Daily spend limit reached (${config.PAYMASTER_DAILY_CAP} cents). Remaining: ${remainingBudgetCents} cents`,
        remainingBudgetCents
      };
    }

    return {
      allowed: true,
      remainingBudgetCents
    };
  }

  /**
   * Check queries per second limit for wallet
   */
  private checkQpsLimit(walletAddress: string): {
    allowed: boolean;
    reason?: string;
    qpsLimitRemaining?: number;
  } {
    const now = Date.now();
    const currentSecond = Math.floor(now / 1000);
    const tracker = this.qpsTracker.get(walletAddress);

    if (!tracker || tracker.secondStart !== currentSecond) {
      // New second, reset counter
      this.qpsTracker.set(walletAddress, {
        secondStart: currentSecond,
        requestCount: 1
      });
      
      return {
        allowed: true,
        qpsLimitRemaining: config.PAYMASTER_QPS_LIMIT - 1
      };
    }

    // Same second, check limit
    if (tracker.requestCount >= config.PAYMASTER_QPS_LIMIT) {
      return {
        allowed: false,
        reason: `QPS limit reached (${config.PAYMASTER_QPS_LIMIT} requests/second). Try again in a moment.`,
        qpsLimitRemaining: 0
      };
    }

    // Increment counter
    tracker.requestCount++;
    
    return {
      allowed: true,
      qpsLimitRemaining: config.PAYMASTER_QPS_LIMIT - tracker.requestCount
    };
  }

  /**
   * Get current date string in YYYY-MM-DD format
   */
  private getTodayString(): string {
    return new Date().toISOString().split('T')[0];
  }

  /**
   * Clean up old tracking data to prevent memory leaks
   */
  private periodicCleanup(): void {
    const now = Date.now();
    
    if (now - this.lastCleanup < this.CLEANUP_INTERVAL) {
      return; // Too soon for cleanup
    }

    this.lastCleanup = now;
    const today = this.getTodayString();

    // Remove spend trackers older than today
    this.dailySpend.forEach((tracker, key) => {
      if (tracker.date !== today) {
        this.dailySpend.delete(key);
      }
    });

    // Remove QPS trackers older than 5 seconds
    const fiveSecondsAgo = Math.floor((now - 5000) / 1000);
    this.qpsTracker.forEach((tracker, walletAddress) => {
      if (tracker.secondStart < fiveSecondsAgo) {
        this.qpsTracker.delete(walletAddress);
      }
    });
  }

  /**
   * Get global paymaster statistics
   */
  getGlobalStats(): {
    totalWalletsToday: number;
    totalSpentCentsToday: number;
    totalTransactionsToday: number;
    avgSpendPerWallet: number;
  } {
    const today = this.getTodayString();
    let totalSpent = 0;
    let totalTransactions = 0;
    let walletCount = 0;

    this.dailySpend.forEach((tracker, key) => {
      if (tracker.date === today) {
        totalSpent += tracker.spentCents;
        totalTransactions += tracker.transactionCount;
        walletCount++;
      }
    });

    return {
      totalWalletsToday: walletCount,
      totalSpentCentsToday: totalSpent,
      totalTransactionsToday: totalTransactions,
      avgSpendPerWallet: walletCount > 0 ? Math.round(totalSpent / walletCount) : 0
    };
  }

  /**
   * Reset all tracking data (useful for testing)
   */
  resetAllData(): void {
    this.dailySpend.clear();
    this.qpsTracker.clear();
  }
}

// Singleton instance
export const paymasterGuard = new PaymasterGuard();