/**
 * Lightweight Metrics Collection System
 * In-memory histograms for route performance tracking
 */

interface RouteMetrics {
  count: number;
  times: number[];
  p50?: number;
  p95?: number;
}

interface PaymasterMetrics {
  calls: number;
  ok: number;
  fail: number;
  spendPct: number;
}

interface ErrorMetrics {
  totalRequests: number;
  errorCount: number;
  errorRate: number;
}

interface WalletMetrics {
  totalAttempts: number;
  successful: number;
  failed: number;
  successRate: number;
}

class MetricsCollector {
  private routes = new Map<string, RouteMetrics>();
  private paymaster: PaymasterMetrics = { calls: 0, ok: 0, fail: 0, spendPct: 0 };
  private errors: ErrorMetrics = { totalRequests: 0, errorCount: 0, errorRate: 0 };
  private wallet: WalletMetrics = { totalAttempts: 0, successful: 0, failed: 0, successRate: 0 };
  private readonly MAX_SAMPLES = 200;

  /**
   * Record route timing
   */
  recordRoute(route: string, durationMs: number): void {
    if (!this.routes.has(route)) {
      this.routes.set(route, { count: 0, times: [] });
    }

    const metrics = this.routes.get(route)!;
    metrics.count++;
    metrics.times.push(durationMs);

    // Keep only last N samples for memory efficiency
    if (metrics.times.length > this.MAX_SAMPLES) {
      metrics.times.shift();
    }

    // Calculate percentiles
    const sorted = [...metrics.times].sort((a, b) => a - b);
    const p50Index = Math.floor(sorted.length * 0.5);
    const p95Index = Math.floor(sorted.length * 0.95);
    
    metrics.p50 = sorted[p50Index] || 0;
    metrics.p95 = sorted[p95Index] || 0;
  }

  /**
   * Record paymaster operation
   */
  recordPaymaster(success: boolean, spendPct: number = 0): void {
    this.paymaster.calls++;
    if (success) {
      this.paymaster.ok++;
    } else {
      this.paymaster.fail++;
    }
    this.paymaster.spendPct = spendPct;
  }

  /**
   * Record HTTP response (for error rate tracking)
   */
  recordResponse(statusCode: number): void {
    this.errors.totalRequests++;
    if (statusCode >= 400) {
      this.errors.errorCount++;
    }
    this.errors.errorRate = this.errors.totalRequests > 0 
      ? (this.errors.errorCount / this.errors.totalRequests) * 100 
      : 0;
  }

  /**
   * Record wallet connection attempt
   */
  recordWalletAttempt(success: boolean): void {
    this.wallet.totalAttempts++;
    if (success) {
      this.wallet.successful++;
    } else {
      this.wallet.failed++;
    }
    this.wallet.successRate = this.wallet.totalAttempts > 0
      ? (this.wallet.successful / this.wallet.totalAttempts) * 100
      : 0;
  }

  /**
   * Get all metrics snapshot
   */
  getMetrics() {
    const routeData: Record<string, { count: number; p50: number; p95: number }> = {};
    
    this.routes.forEach((metrics, route) => {
      routeData[route] = {
        count: metrics.count,
        p50: metrics.p50 || 0,
        p95: metrics.p95 || 0
      };
    });

    return {
      routes: routeData,
      paymaster: { ...this.paymaster },
      errors: { ...this.errors },
      wallet: { ...this.wallet }
    };
  }

  /**
   * Reset all metrics (useful for testing)
   */
  reset(): void {
    this.routes.clear();
    this.paymaster = { calls: 0, ok: 0, fail: 0, spendPct: 0 };
    this.errors = { totalRequests: 0, errorCount: 0, errorRate: 0 };
    this.wallet = { totalAttempts: 0, successful: 0, failed: 0, successRate: 0 };
  }
}

// Singleton instance
export const metrics = new MetricsCollector();

/**
 * Express middleware to time route execution
 */
export function metricsMiddleware(req: any, res: any, next: any): void {
  const start = Date.now();
  const originalSend = res.send;

  res.send = function(body: any) {
    const duration = Date.now() - start;
    const route = `${req.method} ${req.route?.path || req.path}`;
    
    // Record timing for API routes only
    if (req.path.startsWith('/api')) {
      metrics.recordRoute(route, duration);
    }

    // Record response status for error tracking
    metrics.recordResponse(res.statusCode);

    return originalSend.call(this, body);
  };

  next();
}