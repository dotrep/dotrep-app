/**
 * Environment Configuration System
 * Centralized parsing and validation of all environment variables
 */

import { z } from 'zod';

// Environment stage enum
export type EnvironmentStage = 'development' | 'staging' | 'production';

// Config schema with validation
const configSchema = z.object({
  // Core application settings
  NODE_ENV: z.enum(['development', 'production']).default('development'),
  PORT: z.coerce.number().default(5000),
  STAGE: z.enum(['development', 'staging', 'production']).default('development'),
  
  // CORS & Security
  ALLOWED_ORIGINS: z.string().default('http://localhost:5000,https://*.replit.dev,https://*.replit.app'),
  
  // Database
  DATABASE_URL: z.string().min(1),
  
  // Feature flags  
  ENABLE_PAYMASTER: z.coerce.boolean().default(false),
  ENABLE_PULSE: z.coerce.boolean().default(true), 
  ENABLE_SIGNAL: z.coerce.boolean().default(true),
  
  // Paymaster settings
  PAYMASTER_URL: z.string().default('https://paymaster.base.org/api/v1'),
  PAYMASTER_DAILY_CAP: z.coerce.number().default(1000), // USD cents (10.00 USD)
  PAYMASTER_QPS_LIMIT: z.coerce.number().default(10), // Requests per second
  CHAIN_ID: z.coerce.number().default(8453), // Base mainnet
  ALLOWED_WALLETS: z.string().default('coinbase,metamask'),
  
  // Rate limiting
  API_RATE_LIMIT_WINDOW: z.coerce.number().default(15 * 60 * 1000), // 15 minutes
  API_RATE_LIMIT_MAX: z.coerce.number().default(100),
  
  // Session & Auth
  SESSION_SECRET: z.string().min(1),
  
  // Admin credentials
  ADMIN_USERNAME: z.string().min(1).default('admin'),
  ADMIN_PASSWORD: z.string().min(8).default('dev-admin-123!'), // CHANGE IN PRODUCTION!
  
  // Optional services
  HASH_SALT_FOR_IP_DEVICE: z.string().optional(),
});

// Parse and validate environment variables
function parseConfig() {
  try {
    return configSchema.parse(process.env);
  } catch (error) {
    console.error('❌ Invalid environment configuration:');
    if (error instanceof z.ZodError) {
      error.errors.forEach(err => {
        console.error(`  ${err.path.join('.')}: ${err.message}`);
      });
    }
    process.exit(1);
  }
}

// Export validated config
export const config = parseConfig();

// Security warnings for production
if (config.NODE_ENV === 'production') {
  if (config.ADMIN_PASSWORD === 'dev-admin-123!') {
    console.error('🚨 CRITICAL SECURITY WARNING: Default admin password detected in production!');
    console.error('   Set ADMIN_PASSWORD environment variable to a secure password');
    process.exit(1);
  }
  if (config.SESSION_SECRET === 'fsn-vault-session-secret-2025') {
    console.error('🚨 CRITICAL SECURITY WARNING: Default session secret detected in production!');
    console.error('   Set SESSION_SECRET environment variable to a random secure key');
    process.exit(1);
  }
} else {
  // Development warnings
  if (config.ADMIN_PASSWORD === 'dev-admin-123!') {
    console.log('⚠️  Using default admin password for development. Change for production!');
  }
}

// Helper functions
export const isDevelopment = () => config.NODE_ENV === 'development';
export const isProduction = () => config.NODE_ENV === 'production';
export const isStaging = () => config.STAGE === 'staging';

/**
 * Parse CORS origins from comma-separated string
 */
export function getAllowedOrigins(): string[] {
  return config.ALLOWED_ORIGINS
    .split(',')
    .map(origin => origin.trim())
    .filter(origin => origin.length > 0);
}

/**
 * Parse allowed wallets array
 */
export function getAllowedWallets(): string[] {
  return config.ALLOWED_WALLETS
    .split(',')
    .map(wallet => wallet.trim().toLowerCase())
    .filter(wallet => wallet.length > 0);
}

/**
 * Get paymaster configuration
 */
export function getPaymasterConfig() {
  return {
    enabled: config.ENABLE_PAYMASTER,
    url: config.PAYMASTER_URL,
    dailyCapCents: config.PAYMASTER_DAILY_CAP,
    qpsLimit: config.PAYMASTER_QPS_LIMIT,
    chainId: config.CHAIN_ID,
    allowedWallets: getAllowedWallets()
  };
}

// Log configuration on startup
console.log('🔧 Configuration loaded:', {
  stage: config.STAGE,
  nodeEnv: config.NODE_ENV,
  port: config.PORT,
  enablePaymaster: config.ENABLE_PAYMASTER,
  enablePulse: config.ENABLE_PULSE, 
  enableSignal: config.ENABLE_SIGNAL,
  corsOrigins: getAllowedOrigins().length
});