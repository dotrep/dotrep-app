/**
 * Telemetry & Event Logging System
 * Structured logging with privacy protection (address masking, IP hashing)
 */

import crypto from 'crypto';

// Event types for Phase 0
export type TelemetryEvent = 
  | 'claim_start' 
  | 'claim_success' 
  | 'claim_fail'
  | 'pulse_charge'
  | 'signal_toggle' 
  | 'paymaster_call'
  | 'paymaster_error';

interface BaseEventPayload {
  requestId: string;
  timestamp: number;
  walletAddress?: string;
  ip?: string;
  userAgent?: string;
  deviceId?: string;
}

interface ClaimEventPayload extends BaseEventPayload {
  fsnName?: string;
  walletType?: string;
  reason?: string; // For failures
}

interface PulseEventPayload extends BaseEventPayload {
  streakDelta?: number;
  newStreak?: number;
}

interface SignalEventPayload extends BaseEventPayload {
  active: boolean;
  previousState?: boolean;
}

interface PaymasterEventPayload extends BaseEventPayload {
  durationMs: number;
  outcome: 'success' | 'error' | 'timeout';
  spendAmount?: number;
  errorReason?: string;
}

/**
 * Privacy helpers - mask sensitive data
 */
class PrivacyProtector {
  private static readonly HASH_SALT = process.env.HASH_SALT_FOR_IP_DEVICE || 'default-phase0-salt';

  /**
   * Mask wallet address: 0x1234567890abcdef... -> 0x1234...cdef
   */
  static maskAddress(address: string): string {
    if (!address || address.length < 10) return '0x????...????';
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  }

  /**
   * Hash IP address for privacy compliance
   */
  static hashIP(ip: string): string {
    if (!ip) return 'unknown';
    return crypto.createHash('sha256').update(ip + this.HASH_SALT).digest('hex').slice(0, 16);
  }

  /**
   * Hash device ID for privacy compliance  
   */
  static hashDevice(deviceId: string): string {
    if (!deviceId) return 'unknown';
    return crypto.createHash('sha256').update(deviceId + this.HASH_SALT).digest('hex').slice(0, 12);
  }

  /**
   * Clean payload of sensitive data
   */
  static sanitizePayload(payload: any): any {
    const clean = { ...payload };
    
    if (clean.walletAddress) {
      clean.walletAddress = this.maskAddress(clean.walletAddress);
    }
    
    if (clean.ip) {
      clean.ipHash = this.hashIP(clean.ip);
      delete clean.ip;
    }
    
    if (clean.deviceId) {
      clean.deviceHash = this.hashDevice(clean.deviceId);
      delete clean.deviceId;
    }
    
    if (clean.userAgent) {
      // Keep only browser family, remove version details
      clean.browser = this.extractBrowserFamily(clean.userAgent);
      delete clean.userAgent;
    }

    return clean;
  }

  private static extractBrowserFamily(ua: string): string {
    if (ua.includes('Chrome')) return 'chrome';
    if (ua.includes('Firefox')) return 'firefox';  
    if (ua.includes('Safari')) return 'safari';
    if (ua.includes('Edge')) return 'edge';
    return 'unknown';
  }
}

/**
 * Telemetry logger with request ID tracking
 */
class TelemetryLogger {
  /**
   * Log structured event with privacy protection
   */
  logEvent(type: TelemetryEvent, payload: BaseEventPayload): void {
    const timestamp = Date.now();
    const sanitized = PrivacyProtector.sanitizePayload(payload);
    
    const logEntry = {
      event: type,
      timestamp,
      requestId: payload.requestId,
      ...sanitized
    };

    // Structured JSON logging
    console.log(`[TELEMETRY] ${JSON.stringify(logEntry)}`);
  }

  /**
   * Log claim start event
   */
  claimStart(requestId: string, walletAddress: string, fsnName: string, ip?: string, deviceId?: string): void {
    this.logEvent('claim_start', {
      requestId,
      timestamp: Date.now(),
      walletAddress,
      fsnName,
      ip,
      deviceId
    } as any);
  }

  /**
   * Log successful claim
   */
  claimSuccess(requestId: string, walletAddress: string, fsnName: string): void {
    this.logEvent('claim_success', {
      requestId,
      timestamp: Date.now(),
      walletAddress,
      fsnName
    } as any);
  }

  /**
   * Log failed claim
   */
  claimFail(requestId: string, walletAddress: string, reason: string, ip?: string): void {
    this.logEvent('claim_fail', {
      requestId,
      timestamp: Date.now(),
      walletAddress,
      reason,
      ip
    } as any);
  }

  /**
   * Log pulse charge event
   */
  pulseCharge(requestId: string, walletAddress: string, streakDelta: number, newStreak: number): void {
    this.logEvent('pulse_charge', {
      requestId,
      timestamp: Date.now(),
      walletAddress,
      streakDelta,
      newStreak
    } as any);
  }

  /**
   * Log signal toggle event
   */
  signalToggle(requestId: string, walletAddress: string, active: boolean, previousState?: boolean): void {
    this.logEvent('signal_toggle', {
      requestId,
      timestamp: Date.now(),
      walletAddress,
      active,
      previousState
    } as any);
  }

  /**
   * Log paymaster operation
   */
  paymasterCall(requestId: string, walletAddress: string, durationMs: number, outcome: 'success' | 'error' | 'timeout', errorReason?: string): void {
    this.logEvent('paymaster_call', {
      requestId,
      timestamp: Date.now(),  
      walletAddress,
      durationMs,
      outcome,
      errorReason
    } as any);
  }
}

// Singleton instance
export const telemetry = new TelemetryLogger();

/**
 * Request ID middleware - generates unique ID per request
 */
export function requestIdMiddleware(req: any, res: any, next: any): void {
  // Generate unique request ID
  req.requestId = crypto.randomUUID();
  
  // Add to response headers for debugging
  res.setHeader('X-Request-ID', req.requestId);
  
  next();
}

/**
 * Helper to extract client IP considering proxies
 */
export function extractClientIP(req: any): string {
  return req.ip || 
    req.connection?.remoteAddress || 
    req.headers['x-forwarded-for']?.split(',')[0] || 
    req.headers['x-real-ip'] ||
    'unknown';
}