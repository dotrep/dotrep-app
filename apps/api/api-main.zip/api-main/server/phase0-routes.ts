import type { Express } from "express";
import { z } from "zod";
import crypto from "crypto";
import { storage } from "./storage";
import { paymasterService } from "./services/paymasterService";
import { paymasterRateLimit } from "./middleware/enterprise-rate-limit";

// Rate limiting store (in-memory for simplicity)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

// Rate limiter: max 6 writes/min per IP
function rateLimit(ip: string): boolean {
  const now = Date.now();
  const key = crypto.createHash('sha256').update(ip).digest('hex').slice(0, 16);
  
  const current = rateLimitStore.get(key);
  if (!current || now > current.resetTime) {
    rateLimitStore.set(key, { count: 1, resetTime: now + 60 * 1000 });
    return true;
  }
  
  if (current.count >= 6) {
    return false;
  }
  
  current.count++;
  return true;
}

// Helper to hash IP and device ID
function hashString(input: string): string {
  return crypto.createHash('sha256').update(input).digest('hex');
}

// Feature flag helpers
function isFeatureEnabled(feature: string): boolean {
  switch (feature) {
    case 'pulse': return process.env.ENABLE_PULSE === 'true';
    case 'signal': return process.env.ENABLE_SIGNAL === 'true';
    case 'paymaster': return process.env.ENABLE_PAYMASTER === 'true';
    default: return false;
  }
}

export function registerPhase0Routes(app: Express) {
  // POST /api/claim - Claim FSN identity with gasless transaction (CRITICAL FIX: Add paymaster rate limiting)
  app.post('/api/claim', paymasterRateLimit, async (req, res) => {
    try {
      const ip = req.ip || req.connection.remoteAddress || 'unknown';
      
      if (!rateLimit(ip)) {
        return res.status(429).json({ message: 'Rate limit exceeded' });
      }

      const claimSchema = z.object({
        walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
        walletType: z.enum(['coinbase', 'metamask']),
        fsnName: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_-]+$/),
        deviceId: z.string().optional(),
      });

      const { walletAddress, walletType, fsnName, deviceId } = claimSchema.parse(req.body);

      // Check if wallet type is allowed
      const allowedWallets = process.env.ALLOWED_WALLETS?.split(',') || ['coinbase', 'metamask'];
      if (!allowedWallets.includes(walletType)) {
        return res.status(400).json({ message: 'Wallet type not allowed' });
      }

      // Check if FSN name is available
      const existingIdentity = await storage.getFsnIdentityByName(fsnName);
      if (existingIdentity) {
        return res.status(400).json({ message: 'FSN name already taken' });
      }

      // Create or find user by wallet
      let user = await storage.getUserByWallet(walletAddress);
      if (!user) {
        user = await storage.createUser({
          id: crypto.randomUUID(),
          email: null,
          firstName: null,
          lastName: null,
          profileImageUrl: null,
        });
      }

      // Handle paymaster transaction if enabled
      let txHash = 'mock_tx_' + Date.now();
      let sponsoredGas = false;
      
      if (isFeatureEnabled('paymaster')) {
        const walletValidation = await paymasterService.validateWallet(walletAddress, walletType);
        
        if (walletValidation.eligible) {
          const userOp = await paymasterService.constructUserOp(walletAddress, fsnName);
          const sponsorshipResult = await paymasterService.requestSponsorship(userOp, walletType, deviceId);
          
          if (sponsorshipResult.success) {
            const mockSignature = '0x' + crypto.randomBytes(65).toString('hex');
            const submitResult = await paymasterService.submitUserOperation(userOp, mockSignature);
            
            if (submitResult.success && submitResult.txHash) {
              txHash = submitResult.txHash;
              sponsoredGas = true;
              console.log(`✅ Gasless FSN claim: ${fsnName} by ${walletAddress}`);
            }
          }
        }
      }

      // Create FSN identity
      const identity = await storage.createFsnIdentity({
        userId: user.id,
        fsnName,
        walletAddress,
        xp: 50, // Welcome bonus
        pulseCharge: 100,
      });

      // Create pulse state
      await storage.createPulseState({
        userId: user.id,
        streakDays: 0,
        pulseLevel: 'bright',
      });

      // Create signal state
      await storage.createSignal({
        userId: user.id,
        active: false,
      });

      // Log XP event
      await storage.createXpEvent({
        userId: user.id,
        type: 'claim',
        points: 50,
      });

      // Log abuse tracking
      await storage.createAbuseLog({
        userId: user.id,
        deviceId,
        ipHash: hashString(ip),
        event: 'claim',
        metadata: { walletType, fsnName },
      });

      // Update global stats
      await storage.incrementGlobalFsnClaimed();

      console.log(`FSN claimed: ${fsnName} by ${walletAddress}`);

      res.json({ 
        ok: true, 
        txHash,
        userId: user.id, // Include userId for Phase-0 endpoints
        identity: {
          fsnName,
          xp: 50,
          pulseLevel: 'bright',
        }
      });

    } catch (error) {
      console.error('Claim error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid input', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to claim FSN identity' });
    }
  });

  // POST /api/pulse/charge - Charge daily pulse
  app.post('/api/pulse/charge', async (req, res) => {
    try {
      if (!isFeatureEnabled('pulse')) {
        return res.status(403).json({ message: 'Pulse feature disabled' });
      }

      const ip = req.ip || req.connection.remoteAddress || 'unknown';
      
      if (!rateLimit(ip)) {
        return res.status(429).json({ message: 'Rate limit exceeded' });
      }

      const chargeSchema = z.object({
        userId: z.string(),
      });

      const { userId } = chargeSchema.parse(req.body);

      const pulseState = await storage.getPulseStateByUserId(userId);
      if (!pulseState) {
        return res.status(404).json({ message: 'User not found' });
      }

      const now = new Date();
      const lastCharge = pulseState.lastChargeAt;
      
      // Check if already charged today (24h cooldown)
      if (lastCharge && (now.getTime() - lastCharge.getTime()) < 24 * 60 * 60 * 1000) {
        return res.status(400).json({ message: 'Already charged today' });
      }

      // Calculate streak
      let newStreak = pulseState.streakDays || 0;
      let pulseLevel = 'bright';
      
      if (lastCharge) {
        const hoursSinceLastCharge = (now.getTime() - lastCharge.getTime()) / (1000 * 60 * 60);
        
        if (hoursSinceLastCharge <= 48) {
          // Within grace period - continue streak
          newStreak = (pulseState.streakDays || 0) + 1;
        } else {
          // Missed more than 2 days - reset streak
          newStreak = 1;
          pulseLevel = hoursSinceLastCharge <= 72 ? 'dim' : 'dark';
        }
      } else {
        // First charge
        newStreak = 1;
      }

      // Update pulse state
      const updatedPulseState = await storage.updatePulseState(pulseState.id, {
        lastChargeAt: now,
        streakDays: newStreak,
        pulseLevel,
      });

      // Award XP
      const xpPoints = 5;
      await storage.createXpEvent({
        userId,
        type: 'pulse_charge',
        points: xpPoints,
      });

      // Log abuse tracking
      await storage.createAbuseLog({
        userId,
        ipHash: hashString(ip),
        event: 'pulse_charge',
      });

      console.log(`Pulse charged: User ${userId}, streak ${newStreak}`);

      res.json({
        streakDays: newStreak,
        pulseLevel,
        xpToday: xpPoints,
      });

    } catch (error) {
      console.error('Pulse charge error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid input', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to charge pulse' });
    }
  });

  // POST /api/signal/toggle - Toggle signal beacon
  app.post('/api/signal/toggle', async (req, res) => {
    try {
      if (!isFeatureEnabled('signal')) {
        return res.status(403).json({ message: 'Signal feature disabled' });
      }

      const ip = req.ip || req.connection.remoteAddress || 'unknown';
      
      if (!rateLimit(ip)) {
        return res.status(429).json({ message: 'Rate limit exceeded' });
      }

      const toggleSchema = z.object({
        userId: z.string(),
        on: z.boolean(),
      });

      const { userId, on } = toggleSchema.parse(req.body);

      const signal = await storage.getSignalByUserId(userId);
      if (!signal) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Get current active count
      const activeCount = await storage.getActiveSignalCount();
      const signalCap = parseInt(process.env.SIGNAL_CAP || '100000');

      // Check global cap when turning on
      if (on && !signal.active && activeCount >= signalCap) {
        return res.status(400).json({ message: 'Signal capacity reached' });
      }

      // Update signal state
      const updatedSignal = await storage.updateSignal(signal.id, {
        active: on,
        activatedAt: on ? new Date() : null,
      });

      // Award XP for enabling signal
      if (on && !signal.active) {
        await storage.createXpEvent({
          userId,
          type: 'signal_toggle',
          points: 3,
        });
      }

      // Log abuse tracking
      await storage.createAbuseLog({
        userId,
        ipHash: hashString(ip),
        event: 'signal_toggle',
        metadata: { on },
      });

      // Get updated active count
      const newActiveCount = await storage.getActiveSignalCount();

      console.log(`Signal toggled: User ${userId}, active: ${on}`);

      res.json({
        active: on,
        remaining: signalCap - newActiveCount,
      });

    } catch (error) {
      console.error('Signal toggle error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid input', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to toggle signal' });
    }
  });

  // GET /api/leaderboard - Get top active signals
  app.get('/api/leaderboard', async (req, res) => {
    try {
      const limitSchema = z.object({
        limit: z.coerce.number().min(1).max(500).default(100),
      });

      const { limit } = limitSchema.parse(req.query);

      const leaderboard = await storage.getActiveSignalsLeaderboard(limit);

      res.json({
        items: leaderboard,
      });

    } catch (error) {
      console.error('Leaderboard error:', error);
      res.status(500).json({ message: 'Failed to fetch leaderboard' });
    }
  });

  // GET /api/fsn/check-wallet/:walletAddress - Check if wallet has claimed FSN (public endpoint)
  app.get('/api/fsn/check-wallet/:walletAddress', async (req, res) => {
    try {
      const { walletAddress } = req.params;
      
      // Validate wallet address format
      if (!/^0x[a-fA-F0-9]{40}$/.test(walletAddress)) {
        return res.status(400).json({ message: 'Invalid wallet address format' });
      }
      
      // Check if this wallet has claimed an FSN identity
      const identity = await storage.getFsnIdentityByWallet(walletAddress);
      
      if (identity) {
        res.json({
          hasClaimed: true,
          fsnName: identity.fsnName,
          walletAddress: identity.walletAddress,
          xp: identity.xp
        });
      } else {
        res.json({
          hasClaimed: false,
          fsnName: null
        });
      }
    } catch (error) {
      console.error('Error checking wallet FSN identity:', error);
      res.status(500).json({ message: 'Failed to check wallet identity' });
    }
  });

  // GET /api/claim/availability - Check FSN name availability
  app.get('/api/claim/availability', async (req, res) => {
    try {
      const nameSchema = z.object({
        name: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_-]+$/),
      });

      const { name } = nameSchema.parse(req.query);

      const existingIdentity = await storage.getFsnIdentityByName(name);
      const available = !existingIdentity;

      res.json({
        available,
        name,
        reason: available ? 'Available' : 'Name already taken',
      });

    } catch (error) {
      console.error('Name availability error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid input', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to check name availability' });
    }
  });

  // POST /api/claim/start - Start claim reservation (CRITICAL FIX: Add paymaster rate limiting for consistency)
  app.post('/api/claim/start', paymasterRateLimit, async (req, res) => {
    try {
      const startSchema = z.object({
        walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
        fsnName: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_-]+$/),
        deviceId: z.string().optional(),
      });

      const { walletAddress, fsnName, deviceId } = startSchema.parse(req.body);
      const ip = req.ip || req.connection.remoteAddress || 'unknown';

      if (!rateLimit(ip)) {
        return res.status(429).json({ message: 'Rate limit exceeded' });
      }

      // Double-check name availability
      const existingIdentity = await storage.getFsnIdentityByName(fsnName);
      if (existingIdentity) {
        return res.status(400).json({ message: 'Name no longer available' });
      }

      // Check if wallet already has an identity
      const existingUser = await storage.getUserByWallet(walletAddress);
      if (existingUser) {
        const userIdentity = await storage.getFsnIdentityByUserId(existingUser.id);
        if (userIdentity) {
          return res.status(400).json({ message: 'Wallet already has FSN identity' });
        }
      }

      // Create reservation (5-minute window)
      const reservationToken = crypto.randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

      res.json({
        reservationToken,
        expiresAt,
        fsnName,
        walletAddress,
      });

    } catch (error) {
      console.error('Claim start error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid input', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to start claim' });
    }
  });

  // POST /api/claim/execute - Execute gasless claim via paymaster (CRITICAL FIX: Add paymaster rate limiting)
  app.post('/api/claim/execute', paymasterRateLimit, async (req, res) => {
    try {
      const executeSchema = z.object({
        reservationToken: z.string(),
        walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
        walletType: z.enum(['coinbase', 'metamask']),
        fsnName: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_-]+$/),
        deviceId: z.string().optional(),
      });

      const { reservationToken, walletAddress, walletType, fsnName, deviceId } = executeSchema.parse(req.body);
      const ip = req.ip || req.connection.remoteAddress || 'unknown';

      if (!rateLimit(ip)) {
        return res.status(429).json({ message: 'Rate limit exceeded' });
      }

      // Final validation
      const existingIdentity = await storage.getFsnIdentityByName(fsnName);
      if (existingIdentity) {
        return res.status(400).json({ message: 'Name no longer available' });
      }

      // Create or find user
      let user = await storage.getUserByWallet(walletAddress);
      if (!user) {
        user = await storage.createUser({
          id: crypto.randomUUID(),
          email: null,
          firstName: null,
          lastName: null,
          profileImageUrl: null,
        });
      }

      // Handle paymaster transaction
      let txHash = 'mock_tx_' + Date.now();
      let sponsoredGas = false;
      
      if (isFeatureEnabled('paymaster')) {
        const walletValidation = await paymasterService.validateWallet(walletAddress, walletType);
        
        if (walletValidation.eligible) {
          const userOp = await paymasterService.constructUserOp(walletAddress, fsnName);
          const sponsorshipResult = await paymasterService.requestSponsorship(userOp, walletType, deviceId);
          
          if (sponsorshipResult.success) {
            const mockSignature = '0x' + crypto.randomBytes(65).toString('hex');
            const submitResult = await paymasterService.submitUserOperation(userOp, mockSignature);
            
            if (submitResult.success && submitResult.txHash) {
              txHash = submitResult.txHash;
              sponsoredGas = true;
              console.log(`✅ Gasless FSN claim: ${fsnName} by ${walletAddress}`);
            }
          }
        }
      }

      // Create FSN identity
      const identity = await storage.createFsnIdentity({
        userId: user.id,
        fsnName,
        walletAddress,
        xp: 50,
        pulseCharge: 100,
      });

      // Initialize Phase-0 states
      await storage.createPulseState({
        userId: user.id,
        streakDays: 0,
        pulseLevel: 'bright',
      });

      await storage.createSignal({
        userId: user.id,
        active: false,
      });

      // Log events
      await storage.createXpEvent({
        userId: user.id,
        type: 'claim',
        points: 50,
      });

      await storage.createAbuseLog({
        userId: user.id,
        deviceId: deviceId || null,
        ipHash: hashString(ip),
        event: 'claim',
        metadata: { fsnName, walletAddress },
      });

      // Update global stats
      await storage.incrementGlobalFsnClaimed();

      console.log(`FSN claimed: ${fsnName} by ${walletAddress}`);

      res.json({
        success: true,
        fsnName,
        identity: {
          id: identity.id,
          fsnName: identity.fsnName,
          walletAddress: identity.walletAddress,
          xp: identity.xp,
        },
        txHash,
      });

    } catch (error) {
      console.error('Claim execute error:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid input', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to execute claim' });
    }
  });

  // GET /api/pulse/state - Get pulse state for HUD
  app.get('/api/pulse/state/:userId', async (req, res) => {
    try {
      const paramsSchema = z.object({
        userId: z.string(),
      });

      const { userId } = paramsSchema.parse(req.params);

      const pulseState = await storage.getPulseStateByUserId(userId);
      if (!pulseState) {
        return res.status(404).json({ message: 'Pulse state not found' });
      }

      const now = new Date();
      const lastCharge = pulseState.lastChargeAt;
      const canChargeToday = !lastCharge || (now.getTime() - lastCharge.getTime()) >= 24 * 60 * 60 * 1000;

      res.json({
        streakDays: pulseState.streakDays || 0,
        pulseLevel: pulseState.pulseLevel || 'bright',
        lastChargeAt: pulseState.lastChargeAt,
        canChargeToday,
        nextChargeIn: canChargeToday ? 0 : Math.max(0, 24 * 60 * 60 * 1000 - (now.getTime() - (lastCharge?.getTime() || 0))),
      });

    } catch (error) {
      console.error('Pulse state error:', error);
      res.status(500).json({ message: 'Failed to get pulse state' });
    }
  });

  // GET /api/signal/state - Get signal state for HUD
  app.get('/api/signal/state/:userId', async (req, res) => {
    try {
      const paramsSchema = z.object({
        userId: z.string(),
      });

      const { userId } = paramsSchema.parse(req.params);

      const signal = await storage.getSignalByUserId(userId);
      if (!signal) {
        return res.status(404).json({ message: 'Signal state not found' });
      }

      const activeCount = await storage.getActiveSignalCount();
      const signalCap = parseInt(process.env.SIGNAL_CAP || '100000', 10);

      res.json({
        active: signal.active || false,
        activatedAt: signal.activatedAt,
        globalActive: activeCount,
        globalCapacity: signalCap,
        remaining: signalCap - activeCount,
      });

    } catch (error) {
      console.error('Signal state error:', error);
      res.status(500).json({ message: 'Failed to get signal state' });
    }
  });

  // GET /api/xp/summary - Get XP summary for HUD
  app.get('/api/xp/summary/:userId', async (req, res) => {
    try {
      const paramsSchema = z.object({
        userId: z.string(),
      });

      const { userId } = paramsSchema.parse(req.params);

      const identity = await storage.getFsnIdentityByUserId(userId);
      if (!identity) {
        return res.status(404).json({ message: 'User not found' });
      }

      const recentEvents = await storage.getUserXpEvents(userId, 10);
      const todayEvents = recentEvents.filter(
        event => event.timestamp && new Date(event.timestamp).toDateString() === new Date().toDateString()
      );
      const todayXP = todayEvents.reduce((sum, event) => sum + (event.points || 0), 0);

      res.json({
        totalXP: identity.xp || 0,
        level: identity.level || 1,
        todayXP,
        recentEvents: recentEvents.slice(0, 5).map(event => ({
          type: event.type,
          points: event.points,
          timestamp: event.timestamp,
        })),
      });

    } catch (error) {
      console.error('XP summary error:', error);
      res.status(500).json({ message: 'Failed to get XP summary' });
    }
  });

  // GET /api/admin/health - Feature flags and system health
  app.get('/api/admin/health', async (req, res) => {
    try {
      const signalCap = parseInt(process.env.SIGNAL_CAP || '100000');
      const activeSignals = await storage.getActiveSignalCount();

      res.json({
        enablePulse: isFeatureEnabled('pulse'),
        enableSignal: isFeatureEnabled('signal'),
        enablePaymaster: isFeatureEnabled('paymaster'),
        signalCap,
        activeSignals,
        version: '0.1.0-phase0',
        timestamp: new Date().toISOString(),
      });

    } catch (error) {
      console.error('Health check error:', error);
      res.status(500).json({ message: 'Health check failed' });
    }
  });
}