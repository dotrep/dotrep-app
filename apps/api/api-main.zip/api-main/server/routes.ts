import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { registerPhase0Routes } from "./phase0-routes";
import { applyEnhancedSecurity } from "./middleware/enhanced-security";
import { authRateLimit, claimRateLimit, paymasterRateLimit, globalRateLimit } from "./middleware/enterprise-rate-limit";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Apply enhanced security middleware
  applyEnhancedSecurity(app);
  
  // CRITICAL FIX: Apply global rate limiting FIRST for comprehensive protection
  app.use('/api', globalRateLimit);
  
  // Auth middleware
  await setupAuth(app);

  // Auth routes (IP-only rate limiting before auth, then authenticated for user data)
  app.get('/api/auth/user', authRateLimit, isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // FSN Identity routes (dual-key rate limiting after authentication)
  app.get('/api/fsn/identity', isAuthenticated, claimRateLimit, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const identity = await storage.getFsnIdentityByUserId(userId);
      res.json(identity);
    } catch (error) {
      console.error("Error fetching FSN identity:", error);
      res.status(500).json({ message: "Failed to fetch FSN identity" });
    }
  });

  app.post('/api/fsn/claim', isAuthenticated, claimRateLimit, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { fsnName, walletAddress } = req.body;

      const claimSchema = z.object({
        fsnName: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_-]+$/),
        walletAddress: z.string().optional(),
      });

      const validatedData = claimSchema.parse({ fsnName, walletAddress });

      // Check if FSN name is already taken
      const existingIdentity = await storage.getFsnIdentityByName(validatedData.fsnName);
      if (existingIdentity) {
        return res.status(400).json({ message: "FSN name already taken" });
      }

      // Check if user already has an identity
      const userIdentity = await storage.getFsnIdentityByUserId(userId);
      if (userIdentity) {
        return res.status(400).json({ message: "User already has an FSN identity" });
      }

      // Create FSN identity
      const identity = await storage.createFsnIdentity({
        userId,
        fsnName: validatedData.fsnName,
        walletAddress: validatedData.walletAddress,
        xp: 50, // Welcome bonus
        pulseCharge: 100,
      });

      // Award welcome XP
      await storage.createXpActivity({
        fsnIdentityId: identity.id,
        activityType: 'welcome',
        xpEarned: 50,
        description: 'Welcome to FSN!',
      });

      // Update global stats
      await storage.incrementGlobalFsnClaimed();

      res.json(identity);
    } catch (error) {
      console.error("Error claiming FSN identity:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to claim FSN identity" });
    }
  });

  // Pulse system (CRITICAL FIX: Add rate limiting to pulse endpoint)
  app.post('/api/fsn/pulse', isAuthenticated, claimRateLimit, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const identity = await storage.getFsnIdentityByUserId(userId);
      
      if (!identity) {
        return res.status(404).json({ message: "FSN identity not found" });
      }

      if ((identity.pulseCharge || 0) <= 0) {
        return res.status(400).json({ message: "Pulse charge depleted" });
      }

      // Check daily pulse cooldown (24 hours)
      const now = new Date();
      const lastPulse = identity.lastPulseAt;
      if (lastPulse && (now.getTime() - lastPulse.getTime()) < 24 * 60 * 60 * 1000) {
        return res.status(400).json({ message: "Daily pulse already used" });
      }

      // Use pulse and award XP
      const updatedIdentity = await storage.updateFsnIdentity(identity.id, {
        pulseCharge: Math.max(0, (identity.pulseCharge || 0) - 20),
        lastPulseAt: now,
        xp: (identity.xp || 0) + 25,
        lastActiveAt: now,
      });

      await storage.createXpActivity({
        fsnIdentityId: identity.id,
        activityType: 'daily_pulse',
        xpEarned: 25,
        description: 'Daily Pulse completed',
      });

      res.json(updatedIdentity);
    } catch (error) {
      console.error("Error using pulse:", error);
      res.status(500).json({ message: "Failed to use pulse" });
    }
  });

  // Signal system (CRITICAL FIX: Add rate limiting to signal endpoint)
  app.post('/api/fsn/signal/toggle', isAuthenticated, claimRateLimit, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const identity = await storage.getFsnIdentityByUserId(userId);
      
      if (!identity) {
        return res.status(404).json({ message: "FSN identity not found" });
      }

      const newSignalState = !identity.signalActive;
      let xpEarned = 0;

      // Award XP for activating signal
      if (newSignalState && !identity.signalActive) {
        xpEarned = 30;
      }

      const updatedIdentity = await storage.updateFsnIdentity(identity.id, {
        signalActive: newSignalState,
        xp: (identity.xp || 0) + xpEarned,
        lastActiveAt: new Date(),
      });

      if (xpEarned > 0) {
        await storage.createXpActivity({
          fsnIdentityId: identity.id,
          activityType: 'signal',
          xpEarned,
          description: 'Signal activated',
        });
      }

      res.json(updatedIdentity);
    } catch (error) {
      console.error("Error toggling signal:", error);
      res.status(500).json({ message: "Failed to toggle signal" });
    }
  });

  // Global stats (add minimal rate limiting for public endpoint)
  app.get('/api/global/stats', globalRateLimit, async (req, res) => {
    try {
      const stats = await storage.getGlobalStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching global stats:", error);
      res.status(500).json({ message: "Failed to fetch global stats" });
    }
  });

  // XP Activities (dual-key rate limiting after authentication)
  app.get('/api/fsn/activities', isAuthenticated, claimRateLimit, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const identity = await storage.getFsnIdentityByUserId(userId);
      
      if (!identity) {
        return res.status(404).json({ message: "FSN identity not found" });
      }

      const activities = await storage.getXpActivitiesByIdentity(identity.id);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Register Phase-0 routes
  registerPhase0Routes(app);

  // Invite link routes
  const { createInviteLinks, acceptInvite } = await import("./src/invite");
  app.post('/api/admin/invites/create', createInviteLinks);
  app.get('/api/invite/accept', acceptInvite);

  const httpServer = createServer(app);
  return httpServer;
}
