import {
  users,
  fsnIdentities,
  pulseState,
  signals,
  xpEvents,
  xpActivities,
  abuseLog,
  globalStats,
  type User,
  type UpsertUser,
  type FsnIdentity,
  type InsertFsnIdentity,
  type PulseState,
  type InsertPulseState,
  type Signal,
  type InsertSignal,
  type XpEvent,
  type InsertXpEvent,
  type XpActivity,
  type InsertXpActivity,
  type AbuseLog,
  type InsertAbuseLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, count } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (Replit Auth required)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: UpsertUser): Promise<User>;

  // FSN Identity operations
  getFsnIdentityByUserId(userId: string): Promise<FsnIdentity | undefined>;
  getFsnIdentityByName(fsnName: string): Promise<FsnIdentity | undefined>;
  getFsnIdentityByWallet(walletAddress: string): Promise<FsnIdentity | undefined>;
  createFsnIdentity(identity: InsertFsnIdentity): Promise<FsnIdentity>;
  updateFsnIdentity(id: string, updates: Partial<InsertFsnIdentity>): Promise<FsnIdentity>;

  // Phase-0 Pulse operations
  getPulseStateByUserId(userId: string): Promise<PulseState | undefined>;
  createPulseState(pulseState: InsertPulseState): Promise<PulseState>;
  updatePulseState(id: string, updates: Partial<InsertPulseState>): Promise<PulseState>;

  // Phase-0 Signal operations
  getSignalByUserId(userId: string): Promise<Signal | undefined>;
  createSignal(signal: InsertSignal): Promise<Signal>;
  updateSignal(id: string, updates: Partial<InsertSignal>): Promise<Signal>;
  getActiveSignalCount(): Promise<number>;
  getActiveSignalsLeaderboard(limit: number): Promise<Array<{ fsnName: string; streakDays: number }>>;

  // Phase-0 XP Events
  createXpEvent(xpEvent: InsertXpEvent): Promise<XpEvent>;
  getUserXpEvents(userId: string, limit?: number): Promise<XpEvent[]>;

  // XP Activities (FSN Identity based)
  createXpActivity(xpActivity: InsertXpActivity): Promise<XpActivity>;
  getXpActivitiesByIdentity(fsnIdentityId: string, limit?: number): Promise<XpActivity[]>;

  // Phase-0 Abuse Log
  createAbuseLog(abuseLog: InsertAbuseLog): Promise<AbuseLog>;

  // Global stats
  getGlobalStats(): Promise<{ totalFsnClaimed: number; activeSignals: number; dailyPulses: number; lastUpdated: Date | null; } | undefined>;
  incrementGlobalFsnClaimed(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    const [identity] = await db
      .select({ user: users })
      .from(fsnIdentities)
      .leftJoin(users, eq(fsnIdentities.userId, users.id))
      .where(eq(fsnIdentities.walletAddress, walletAddress));
    return identity?.user || undefined;
  }

  async createUser(userData: UpsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  // FSN Identity operations
  async getFsnIdentityByUserId(userId: string): Promise<FsnIdentity | undefined> {
    const [identity] = await db
      .select()
      .from(fsnIdentities)
      .where(eq(fsnIdentities.userId, userId));
    return identity;
  }

  async getFsnIdentityByName(fsnName: string): Promise<FsnIdentity | undefined> {
    const [identity] = await db
      .select()
      .from(fsnIdentities)
      .where(eq(fsnIdentities.fsnName, fsnName));
    return identity;
  }

  async getFsnIdentityByWallet(walletAddress: string): Promise<FsnIdentity | undefined> {
    const [identity] = await db
      .select()
      .from(fsnIdentities)
      .where(eq(fsnIdentities.walletAddress, walletAddress));
    return identity;
  }

  async createFsnIdentity(identityData: InsertFsnIdentity): Promise<FsnIdentity> {
    const [identity] = await db.insert(fsnIdentities).values(identityData).returning();
    return identity;
  }

  async updateFsnIdentity(id: string, updates: Partial<InsertFsnIdentity>): Promise<FsnIdentity> {
    const [identity] = await db
      .update(fsnIdentities)
      .set(updates)
      .where(eq(fsnIdentities.id, id))
      .returning();
    return identity;
  }

  // Phase-0 Pulse operations
  async getPulseStateByUserId(userId: string): Promise<PulseState | undefined> {
    const [pulse] = await db
      .select()
      .from(pulseState)
      .where(eq(pulseState.userId, userId));
    return pulse;
  }

  async createPulseState(pulseData: InsertPulseState): Promise<PulseState> {
    const [pulse] = await db.insert(pulseState).values(pulseData).returning();
    return pulse;
  }

  async updatePulseState(id: string, updates: Partial<InsertPulseState>): Promise<PulseState> {
    const [pulse] = await db
      .update(pulseState)
      .set(updates)
      .where(eq(pulseState.id, id))
      .returning();
    return pulse;
  }

  // Phase-0 Signal operations
  async getSignalByUserId(userId: string): Promise<Signal | undefined> {
    const [signal] = await db
      .select()
      .from(signals)
      .where(eq(signals.userId, userId));
    return signal;
  }

  async createSignal(signalData: InsertSignal): Promise<Signal> {
    const [signal] = await db.insert(signals).values(signalData).returning();
    return signal;
  }

  async updateSignal(id: string, updates: Partial<InsertSignal>): Promise<Signal> {
    const [signal] = await db
      .update(signals)
      .set(updates)
      .where(eq(signals.id, id))
      .returning();
    return signal;
  }

  async getActiveSignalCount(): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(signals)
      .where(eq(signals.active, true));
    return result.count;
  }

  async getActiveSignalsLeaderboard(limit: number): Promise<Array<{ fsnName: string; streakDays: number }>> {
    const results = await db
      .select({
        fsnName: fsnIdentities.fsnName,
        streakDays: pulseState.streakDays,
      })
      .from(signals)
      .leftJoin(fsnIdentities, eq(signals.userId, fsnIdentities.userId))
      .leftJoin(pulseState, eq(signals.userId, pulseState.userId))
      .where(eq(signals.active, true))
      .orderBy(desc(signals.activatedAt))
      .limit(limit);

    return results.map(r => ({
      fsnName: r.fsnName || 'unknown',
      streakDays: r.streakDays || 0,
    }));
  }

  // Phase-0 XP Events
  async createXpEvent(xpEventData: InsertXpEvent): Promise<XpEvent> {
    const [xpEvent] = await db.insert(xpEvents).values(xpEventData).returning();
    return xpEvent;
  }

  async getUserXpEvents(userId: string, limit = 50): Promise<XpEvent[]> {
    return await db
      .select()
      .from(xpEvents)
      .where(eq(xpEvents.userId, userId))
      .orderBy(desc(xpEvents.timestamp))
      .limit(limit);
  }

  // XP Activities (FSN Identity based)
  async createXpActivity(xpActivityData: InsertXpActivity): Promise<XpActivity> {
    const [activity] = await db.insert(xpActivities).values(xpActivityData).returning();
    return activity;
  }

  async getXpActivitiesByIdentity(fsnIdentityId: string, limit = 50): Promise<XpActivity[]> {
    return await db
      .select()
      .from(xpActivities)
      .where(eq(xpActivities.fsnIdentityId, fsnIdentityId))
      .orderBy(desc(xpActivities.createdAt))
      .limit(limit);
  }

  // Phase-0 Abuse Log
  async createAbuseLog(abuseLogData: InsertAbuseLog): Promise<AbuseLog> {
    const [log] = await db.insert(abuseLog).values(abuseLogData).returning();
    return log;
  }

  // Global stats
  async getGlobalStats(): Promise<{ totalFsnClaimed: number; activeSignals: number; dailyPulses: number; lastUpdated: Date | null; } | undefined> {
    const [stats] = await db.select().from(globalStats).where(eq(globalStats.id, 'global'));
    if (!stats) {
      // Initialize global stats if not exists
      await db.insert(globalStats).values({
        id: 'global',
        totalFsnClaimed: 8421,
        activeSignals: 0,
        dailyPulses: 0,
        lastUpdated: new Date(),
      }).onConflictDoNothing();
      return { totalFsnClaimed: 8421, activeSignals: 0, dailyPulses: 0, lastUpdated: new Date() };
    }
    return {
      totalFsnClaimed: Number(stats.totalFsnClaimed) || 8421,
      activeSignals: stats.activeSignals || 0,
      dailyPulses: stats.dailyPulses || 0,
      lastUpdated: stats.lastUpdated,
    };
  }

  async incrementGlobalFsnClaimed(): Promise<void> {
    await db
      .update(globalStats)
      .set({
        totalFsnClaimed: sql`${globalStats.totalFsnClaimed} + 1`,
        lastUpdated: new Date(),
      })
      .where(eq(globalStats.id, 'global'));
  }
}

export const storage = new DatabaseStorage();