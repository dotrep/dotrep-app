/**
 * Enhanced Security Middleware
 * 
 * Combines Helmet.js security headers with CORS configuration
 * for comprehensive Phase-0 API protection.
 */

import helmet from 'helmet';
import cors from 'cors';
import type { Express } from 'express';
import { getAllowedOrigins } from '../src/config';

/**
 * Apply enhanced security middleware to Express app
 */
export function applyEnhancedSecurity(app: Express): void {
  // Helmet.js - Security headers
  app.use(
    helmet({
      // Content Security Policy
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: process.env.NODE_ENV === 'development' 
            ? ["'self'", "'unsafe-inline'"] 
            : ["'self'"],
          styleSrc: process.env.NODE_ENV === 'development' 
            ? ["'self'", "'unsafe-inline'"] 
            : ["'self'"],
          imgSrc: ["'self'", "data:", "blob:", "https:"],
          fontSrc: ["'self'", "https:", "data:"],
          connectSrc: [
            "'self'",
            "wss:", // WebSocket connections
            "https://sepolia.base.org", // Base Sepolia RPC
            "https://mainnet.base.org", // Base Mainnet RPC
            "https://paymaster.base.org", // Paymaster service
          ],
          mediaSrc: ["'self'"],
          objectSrc: ["'none'"],
          frameSrc: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
          frameAncestors: ["'none'"],
          reportUri: ["/api/csp-report"]
        },
        reportOnly: process.env.NODE_ENV === 'development',
      },

      // Cross-Origin Headers
      crossOriginEmbedderPolicy: false, // Allow Coinbase Wallet integration
      crossOriginOpenerPolicy: false,   // Allow Coinbase Wallet SDK popup communication
      crossOriginResourcePolicy: { policy: 'cross-origin' },

      // DNS Prefetch Control
      dnsPrefetchControl: { allow: false },

      // Frame Options
      frameguard: { action: 'deny' },

      // Hide Powered-By Header
      hidePoweredBy: true,

      // HTTP Strict Transport Security
      hsts: {
        maxAge: 31536000, // 1 year
        includeSubDomains: true,
        preload: true,
      },

      // IE No Open
      ieNoOpen: true,

      // MIME Type Sniffing
      noSniff: true,

      // Origin Agent Cluster
      originAgentCluster: true,

      // Referrer Policy
      referrerPolicy: { policy: 'same-origin' },

      // X-XSS-Protection
      xssFilter: true,
    })
  );

  // CORS Configuration
  const corsOptions = {
    origin: (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) => {
      // Allow requests with no origin (mobile apps, Postman, etc.)
      if (!origin) return callback(null, true);

      // Development: Allow localhost origins
      if (process.env.NODE_ENV === 'development') {
        const allowedOrigins = [
          'http://localhost:3000',
          'http://localhost:5000',
          'http://127.0.0.1:3000',
          'http://127.0.0.1:5000',
          /^https:\/\/.*\.replit\.app$/,
          /^https:\/\/.*\.replit\.dev$/,
        ];

        const isAllowed = allowedOrigins.some(allowed => {
          if (typeof allowed === 'string') {
            return origin === allowed;
          }
          return allowed.test(origin);
        });

        return callback(null, isAllowed);
      }

      // Production: Strict origin validation
      const productionOrigins = [
        'https://fsn.network',
        'https://www.fsn.network',
        'https://app.fsn.network',
        /^https:\/\/.*\.fsn\.network$/,
        /^https:\/\/.*\.replit\.app$/,
      ];

      const isAllowed = productionOrigins.some(allowed => {
        if (typeof allowed === 'string') {
          return origin === allowed;
        }
        return allowed.test(origin);
      });

      if (isAllowed) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS policy'), false);
      }
    },

    // Allowed Methods
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],

    // Allowed Headers
    allowedHeaders: [
      'Content-Type',
      'Authorization',
      'X-Requested-With',
      'X-Device-ID',
      'X-Client-Version',
      'Accept',
      'Origin',
    ],

    // Exposed Headers
    exposedHeaders: [
      'X-Total-Count',
      'X-Rate-Limit-Remaining',
      'X-Rate-Limit-Reset',
    ],

    // Credentials Support
    credentials: true,

    // Preflight Cache
    maxAge: 86400, // 24 hours
  };

  app.use(cors(corsOptions));

  // Additional Phase-0 security headers
  app.use((req, res, next) => {
    // Anti-fingerprinting
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    
    // Permissions Policy - restrict potentially harmful APIs
    res.setHeader('Permissions-Policy', 'geolocation=(), microphone=(), camera=(), payment=(), usb=(), magnetometer=(), gyroscope=()');

    // Cache Control for sensitive endpoints
    if (req.path.startsWith('/api/')) {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }

    // ERC-4337 specific headers
    if (req.path.includes('/claim/') || req.path.includes('/paymaster/')) {
      res.setHeader('X-Frame-Options', 'DENY');
      res.setHeader('X-Content-Type-Options', 'nosniff');
    }

    next();
  });

  console.log('✅ Enhanced security middleware applied');
}

/**
 * Rate limiting configuration for different endpoint types
 */
export const rateLimitConfig = {
  // Standard API endpoints
  standard: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // 100 requests per window
    message: 'Too many requests, please try again later',
  },

  // Authentication endpoints
  auth: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 attempts per window
    message: 'Too many authentication attempts, please try again later',
  },

  // FSN claiming endpoints
  claim: {
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3, // 3 claim attempts per hour
    message: 'Too many claim attempts, please try again later',
  },

  // Paymaster endpoints
  paymaster: {
    windowMs: 10 * 60 * 1000, // 10 minutes
    max: 10, // 10 paymaster requests per window
    message: 'Too many gasless transaction requests, please try again later',
  },

  // HUD state endpoints
  hud: {
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 30, // 30 requests per minute
    message: 'Too many HUD requests, please try again later',
  },
};