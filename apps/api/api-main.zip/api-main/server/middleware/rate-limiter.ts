/**
 * Rate limiting middleware for FSN platform security
 * 
 * Implements protection against brute force attacks on authentication
 * and other sensitive endpoints
 */
import rateLimit from 'express-rate-limit';

// Standard rate limiter for general API endpoints
export const standardLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per window
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  message: 'Too many requests from this IP, please try again after 15 minutes',
});

// Strict rate limiter for authentication endpoints (login, password reset, etc.)
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 login attempts per window
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Too many authentication attempts from this IP, please try again after 15 minutes',
});

// Rate limiter for email sending (prevents spamming users with emails)
export const emailLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // Limit each IP to 3 email requests per hour
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Too many email requests from this IP, please try again after an hour',
});

// Rate limiter for FSN name availability checking
export const fsnNameLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes
  max: 20, // Limit each IP to 20 name availability checks per window
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Too many FSN name availability checks from this IP, please try again after 10 minutes',
});

// Enhanced rate limiter for FSN claim operations (per device)
export const fsnClaimLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // Allow only 3 claim attempts per device per hour
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    // Use device ID from headers or fallback to IP
    const deviceId = req.headers['x-device-id'] as string;
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    return deviceId || `ip_${ip}`;
  },
  message: 'Too many FSN claim attempts from this device, please try again after an hour',
  onLimitReached: (req, res) => {
    const retryAfter = Math.ceil((60 * 60 * 1000) / 1000); // 1 hour
    res.set('Retry-After', retryAfter.toString());
  }
});

// Rate limiter for pulse charging (daily streaks)
export const pulseChargeLimiter = rateLimit({
  windowMs: 24 * 60 * 60 * 1000, // 24 hours
  max: 5, // Allow 5 pulse charge attempts per day per device (in case of failures)
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    const deviceId = req.headers['x-device-id'] as string;
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    return `pulse_${deviceId || `ip_${ip}`}`;
  },
  message: 'Too many pulse charge attempts from this device, please try again tomorrow',
  onLimitReached: (req, res) => {
    const retryAfter = Math.ceil((24 * 60 * 60 * 1000) / 1000); // 24 hours
    res.set('Retry-After', retryAfter.toString());
  }
});

// Rate limiter for signal toggle operations
export const signalToggleLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // Allow 10 signal toggles per 15 minutes per device
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    const deviceId = req.headers['x-device-id'] as string;
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    return `signal_${deviceId || `ip_${ip}`}`;
  },
  message: 'Too many signal toggle attempts from this device, please try again in 15 minutes',
  onLimitReached: (req, res) => {
    const retryAfter = Math.ceil((15 * 60 * 1000) / 1000); // 15 minutes
    res.set('Retry-After', retryAfter.toString());
  }
});

// Strict rate limiter for paymaster operations
export const paymasterLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 5, // Very conservative limit for gasless transactions
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    const deviceId = req.headers['x-device-id'] as string;
    const walletAddress = req.body?.walletAddress || req.query?.walletAddress;
    const ip = req.ip || req.connection?.remoteAddress || 'unknown';
    // Combine wallet + device for more precise limiting
    return `paymaster_${walletAddress}_${deviceId || `ip_${ip}`}`;
  },
  message: 'Too many paymaster requests from this device/wallet combination, please try again in a minute',
  onLimitReached: (req, res) => {
    // Add custom retry-after header
    const windowMs = 60 * 1000; // 1 minute
    const retryAfter = Math.ceil(windowMs / 1000);
    res.set('Retry-After', retryAfter.toString());
  }
});