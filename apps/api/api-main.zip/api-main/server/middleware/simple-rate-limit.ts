/**
 * Simple in-memory rate limiter for FSN critical endpoints
 * Protects against brute force attacks on auth/claim/paymaster routes
 */
import type { Request, Response, NextFunction } from 'express';

interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

const store: RateLimitStore = {};

export function createRateLimit(windowMs: number, max: number, message: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = req.ip || 'unknown';
    const now = Date.now();
    
    // Clean expired entries
    if (store[key] && now > store[key].resetTime) {
      delete store[key];
    }
    
    // Initialize or increment
    if (!store[key]) {
      store[key] = {
        count: 1,
        resetTime: now + windowMs
      };
    } else {
      store[key].count++;
    }
    
    // Check limit
    if (store[key].count > max) {
      res.setHeader('Retry-After', Math.ceil((store[key].resetTime - now) / 1000));
      res.setHeader('X-Rate-Limit-Remaining', '0');
      res.setHeader('X-Rate-Limit-Reset', store[key].resetTime.toString());
      return res.status(429).json({ message });
    }
    
    // Set headers
    res.setHeader('X-Rate-Limit-Remaining', (max - store[key].count).toString());
    res.setHeader('X-Rate-Limit-Reset', store[key].resetTime.toString());
    
    next();
  };
}

// Rate limiters for different endpoint types
export const authRateLimit = createRateLimit(
  15 * 60 * 1000, // 15 minutes
  5, // 5 attempts
  'Too many authentication attempts, please try again later'
);

export const claimRateLimit = createRateLimit(
  60 * 60 * 1000, // 1 hour  
  3, // 3 attempts
  'Too many claim attempts, please try again later'
);

export const standardRateLimit = createRateLimit(
  15 * 60 * 1000, // 15 minutes
  100, // 100 requests
  'Too many requests, please try again later'
);