/**
 * Enterprise-grade rate limiting for FSN critical endpoints
 * Addresses architect security requirements:
 * - Memory-bounded with immediate LRU cleanup
 * - Dual keying (IP + user) with proper auth ordering
 * - RFC 9239 compliant headers with delta seconds
 * - Comprehensive endpoint protection
 * - Immediate memory DoS prevention
 */
import type { Request, Response, NextFunction } from 'express';

interface RateLimitEntry {
  count: number;
  resetTime: number;
  lastUpdate: number;
}

interface RateLimitStore {
  [key: string]: RateLimitEntry;
}

interface RateLimitResult {
  remainingPoints: number;
  msBeforeNext: number;
  totalHits: number;
}

class EnterpriseRateLimiter {
  private store: RateLimitStore = {};
  private maxKeys = 10000; // LRU limit to prevent memory DoS
  private cleanupInterval: NodeJS.Timeout;
  public readonly points: number; // Expose for middleware access
  public readonly windowMs: number;
  public readonly keyPrefix: string;

  constructor(
    points: number,
    windowMs: number,
    keyPrefix: string
  ) {
    this.points = points;
    this.windowMs = windowMs;
    this.keyPrefix = keyPrefix;
    
    // Auto-cleanup every 2 minutes (more frequent)
    this.cleanupInterval = setInterval(() => this.cleanup(), 2 * 60 * 1000);
  }

  private cleanup() {
    const now = Date.now();
    const keysToDelete: string[] = [];
    
    for (const [key, entry] of Object.entries(this.store)) {
      if (now > entry.resetTime) {
        keysToDelete.push(key);
      }
    }
    
    keysToDelete.forEach(key => delete this.store[key]);
    
    // LRU cleanup if too many keys
    this.enforceLRULimit();
  }

  // CRITICAL FIX: Immediate LRU enforcement to prevent memory DoS
  private enforceLRULimit() {
    const currentKeys = Object.keys(this.store);
    if (currentKeys.length > this.maxKeys) {
      const sortedKeys = currentKeys
        .sort((a, b) => this.store[a].lastUpdate - this.store[b].lastUpdate)
        .slice(0, currentKeys.length - this.maxKeys);
      
      sortedKeys.forEach(key => delete this.store[key]);
    }
  }

  async consume(key: string): Promise<RateLimitResult> {
    const now = Date.now();
    const fullKey = `${this.keyPrefix}:${key}`;
    
    // Clean expired entry
    if (this.store[fullKey] && now > this.store[fullKey].resetTime) {
      delete this.store[fullKey];
    }
    
    // CRITICAL FIX: Enforce LRU limit immediately on new key insertion
    if (!this.store[fullKey] && Object.keys(this.store).length >= this.maxKeys) {
      this.enforceLRULimit();
    }
    
    // Initialize or increment
    if (!this.store[fullKey]) {
      this.store[fullKey] = {
        count: 1,
        resetTime: now + this.windowMs,
        lastUpdate: now
      };
    } else {
      this.store[fullKey].count++;
      this.store[fullKey].lastUpdate = now;
    }
    
    const entry = this.store[fullKey];
    const remainingPoints = Math.max(0, this.points - entry.count);
    const msBeforeNext = Math.max(0, entry.resetTime - now);
    
    const result: RateLimitResult = {
      remainingPoints,
      msBeforeNext,
      totalHits: entry.count
    };
    
    if (entry.count > this.points) {
      throw result;
    }
    
    return result;
  }

  destroy() {
    clearInterval(this.cleanupInterval);
  }
}

// Enterprise rate limiters with immediate cleanup
const authLimiter = new EnterpriseRateLimiter(5, 15 * 60 * 1000, 'auth');
const claimLimiter = new EnterpriseRateLimiter(3, 60 * 60 * 1000, 'claim');  
const paymasterLimiter = new EnterpriseRateLimiter(10, 60 * 60 * 1000, 'paymaster');
const globalLimiter = new EnterpriseRateLimiter(100, 15 * 60 * 1000, 'global');

// QA bypass functionality for testing
function checkQABypass(req: Request): boolean {
  const qaBypass = req.headers['x-qa-bypass'] as string;
  const qaSecret = process.env.QA_BYPASS_SECRET;
  
  // Only allow bypass if secret is configured and matches
  if (qaSecret && qaBypass === qaSecret) {
    console.log(`QA bypass activated for ${req.method} ${req.path} from ${req.ip}`);
    return true;
  }
  
  return false;
}

// CRITICAL FIX: Create separate IP-only and dual-key middleware factories
// IP-only limiter for pre-auth endpoints
function createIPRateLimitMiddleware(limiter: EnterpriseRateLimiter, message: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    // Check for QA bypass first
    if (checkQABypass(req)) {
      return next();
    }
    
    try {
      const key = `${req.ip}`; // IP-only keying for pre-auth
      
      const result = await limiter.consume(key);
      
      // RFC 9239 compliant headers - CRITICAL FIX: delta seconds for Reset
      res.setHeader('RateLimit-Limit', limiter.points.toString());
      res.setHeader('RateLimit-Remaining', result.remainingPoints.toString());
      res.setHeader('RateLimit-Reset', Math.ceil(result.msBeforeNext / 1000).toString()); // Delta seconds
      res.setHeader('RateLimit-Policy', `${limiter.points};w=${Math.ceil(limiter.windowMs / 1000)}`);
      
      next();
    } catch (rateLimitRes: any) {
      const secs = Math.ceil((rateLimitRes.msBeforeNext || 0) / 1000);
      
      // RFC 9239 compliant error headers
      res.setHeader('Retry-After', secs.toString());
      res.setHeader('RateLimit-Limit', limiter.points.toString());
      res.setHeader('RateLimit-Remaining', '0');
      res.setHeader('RateLimit-Reset', secs.toString()); // Delta seconds
      res.setHeader('RateLimit-Policy', `${limiter.points};w=${Math.ceil(limiter.windowMs / 1000)}`);
      
      // Enhanced security logging
      console.warn(`Rate limit exceeded [IP-only]: ${req.method} ${req.path} from ${req.ip} (${rateLimitRes.totalHits}/${limiter.points})`);
      
      return res.status(429).json({ 
        message,
        retryAfter: secs,
        limit: limiter.points,
        remaining: 0,
        reset: secs
      });
    }
  };
}

// Dual-key limiter for post-auth endpoints with IP+user keying
function createDualKeyRateLimitMiddleware(limiter: EnterpriseRateLimiter, message: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    // Check for QA bypass first
    if (checkQABypass(req)) {
      return next();
    }
    
    try {
      const user = (req as any).user?.claims?.sub;
      const key = `${req.ip}:${user || 'anonymous'}`; // Dual keying IP+user
      
      const result = await limiter.consume(key);
      
      // RFC 9239 compliant headers - CRITICAL FIX: delta seconds for Reset
      res.setHeader('RateLimit-Limit', limiter.points.toString());
      res.setHeader('RateLimit-Remaining', result.remainingPoints.toString());
      res.setHeader('RateLimit-Reset', Math.ceil(result.msBeforeNext / 1000).toString()); // Delta seconds
      res.setHeader('RateLimit-Policy', `${limiter.points};w=${Math.ceil(limiter.windowMs / 1000)}`);
      
      next();
    } catch (rateLimitRes: any) {
      const secs = Math.ceil((rateLimitRes.msBeforeNext || 0) / 1000);
      const user = (req as any).user?.claims?.sub;
      
      // RFC 9239 compliant error headers
      res.setHeader('Retry-After', secs.toString());
      res.setHeader('RateLimit-Limit', limiter.points.toString());
      res.setHeader('RateLimit-Remaining', '0');
      res.setHeader('RateLimit-Reset', secs.toString()); // Delta seconds
      res.setHeader('RateLimit-Policy', `${limiter.points};w=${Math.ceil(limiter.windowMs / 1000)}`);
      
      // Enhanced security logging with user context
      console.warn(`Rate limit exceeded [Dual-key]: ${req.method} ${req.path} from ${req.ip} user:${user || 'anonymous'} (${rateLimitRes.totalHits}/${limiter.points})`);
      
      return res.status(429).json({ 
        message,
        retryAfter: secs,
        limit: limiter.points,
        remaining: 0,
        reset: secs
      });
    }
  };
}

// CRITICAL FIX: Export properly differentiated middleware
// IP-only rate limiters for pre-authentication endpoints
export const authRateLimit = createIPRateLimitMiddleware(
  authLimiter, 
  'Too many authentication attempts'
);

export const globalRateLimit = createIPRateLimitMiddleware(
  globalLimiter,
  'Too many requests'
);

// Dual-key rate limiters for authenticated endpoints
export const claimRateLimit = createDualKeyRateLimitMiddleware(
  claimLimiter,
  'Too many claim attempts'
);

export const paymasterRateLimit = createDualKeyRateLimitMiddleware(
  paymasterLimiter,
  'Too many paymaster requests'
);

// Cleanup function for graceful shutdown
export const destroyRateLimiters = () => {
  authLimiter.destroy();
  claimLimiter.destroy();
  paymasterLimiter.destroy();
  globalLimiter.destroy();
};