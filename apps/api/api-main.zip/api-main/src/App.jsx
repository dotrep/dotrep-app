import React from "react";
import Picture6Dashboard from "./components/Picture6Dashboard";

const App = () => {
  return <Picture6Dashboard />;
};

export default App;
