export const addresses = {
  baseSepolia: { 
    fsnRegistry: "", 
    fsnVault: "", 
    eas: process.env.NEXT_PUBLIC_EAS_ADDRESS || "0x0000000000000000000000000000000000000000" 
  },
  base: { 
    fsnRegistry: "", 
    fsnVault: "", 
    eas: "0x0000000000000000000000000000000000000000" 
  }
};

export const abis = { 
  fsnRegistry: [], 
  fsnVault: [] 
};