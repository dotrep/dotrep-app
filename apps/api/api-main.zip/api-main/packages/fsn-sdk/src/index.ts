import { createPublicClient, http } from "viem";
import { writeContract } from "wagmi/actions";
import { EAS, SchemaEncoder } from "@ethereum-attestation-service/eas-sdk";

const CHAIN_ID = Number(process.env.NEXT_PUBLIC_BASE_CHAIN_ID || 84532); // Sepolia by default
const RPC = CHAIN_ID === 84532 ? "https://sepolia.base.org" : "https://mainnet.base.org";
export const client = createPublicClient({ transport: http(RPC) });

/** Replace with your real addresses/ABIs via packages/contracts */
export const FSN_REGISTRY_ADDR = process.env.NEXT_PUBLIC_FSN_REGISTRY_ADDR as `0x${string}` | undefined;
export const FSN_REGISTRY_ABI: any = [];
export const EAS_ADDRESS = process.env.NEXT_PUBLIC_EAS_ADDRESS as `0x${string}` | undefined;

/** Paymaster-sponsored write placeholders (actual sponsorship handled by OnchainKit config) */
export async function claimHandleSponsored(handle: string) {
  if (!FSN_REGISTRY_ADDR) throw new Error("FSN_REGISTRY_ADDR missing");
  // TODO: replace "claim" with your registry method + args
  // return await writeContract({ address: FSN_REGISTRY_ADDR, abi: FSN_REGISTRY_ABI, functionName: "claim", args: [handle] });
  return Promise.resolve(true);
}

export async function dailyCheckInSponsored() {
  // TODO: call your streak/check-in method
  return Promise.resolve(true);
}

/** EAS read helper */
export async function getFsnProfile() {
  if (!EAS_ADDRESS) throw new Error("NEXT_PUBLIC_EAS_ADDRESS missing");
  const eas = new EAS(EAS_ADDRESS);
  // TODO: connect provider, query attestations by schemaId for the connected wallet
  return { xp: 0, streak: 0, handle: "", badges: [] };
}