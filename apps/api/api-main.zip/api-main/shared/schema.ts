import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  integer,
  boolean,
  text,
  bigint,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// FSN Identity table
export const fsnIdentities = pgTable("fsn_identities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  fsnName: varchar("fsn_name").unique().notNull(),
  walletAddress: varchar("wallet_address"),
  isVerified: boolean("is_verified").default(false),
  claimedAt: timestamp("claimed_at").defaultNow(),
  xp: integer("xp").default(0),
  level: integer("level").default(1),
  pulseCharge: integer("pulse_charge").default(100),
  lastPulseAt: timestamp("last_pulse_at"),
  signalActive: boolean("signal_active").default(false),
  trustScore: integer("trust_score").default(0),
  streakDays: integer("streak_days").default(0),
  lastActiveAt: timestamp("last_active_at").defaultNow(),
});

// XP Activities tracking
export const xpActivities = pgTable("xp_activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fsnIdentityId: varchar("fsn_identity_id").references(() => fsnIdentities.id).notNull(),
  activityType: varchar("activity_type").notNull(), // 'upload', 'signal', 'quest', 'daily_pulse'
  xpEarned: integer("xp_earned").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Badges earned by users
export const badges = pgTable("badges", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  iconPath: varchar("icon_path"),
  rarity: varchar("rarity").default('common'), // 'common', 'rare', 'epic', 'legendary'
  xpBonus: integer("xp_bonus").default(0),
  requirements: jsonb("requirements"), // JSON object describing unlock requirements
});

export const userBadges = pgTable("user_badges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fsnIdentityId: varchar("fsn_identity_id").references(() => fsnIdentities.id).notNull(),
  badgeId: varchar("badge_id").references(() => badges.id).notNull(),
  earnedAt: timestamp("earned_at").defaultNow(),
  isEquipped: boolean("is_equipped").default(false),
});

// Global counters and scarcity tracking
export const globalStats = pgTable("global_stats", {
  id: varchar("id").primaryKey().default('global'),
  totalFsnClaimed: bigint("total_fsn_claimed", { mode: "number" }).default(8421),
  activeSignals: integer("active_signals").default(0),
  dailyPulses: integer("daily_pulses").default(0),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Relations
export const usersRelations = {
  fsnIdentity: {
    from: users,
    to: fsnIdentities,
    type: "one-to-one" as const,
  },
};

export const fsnIdentitiesRelations = {
  user: {
    from: fsnIdentities,
    to: users,
    type: "many-to-one" as const,
  },
  activities: {
    from: fsnIdentities,
    to: xpActivities,
    type: "one-to-many" as const,
  },
  badges: {
    from: fsnIdentities,
    to: userBadges,
    type: "one-to-many" as const,
  },
};

// Zod schemas
export const insertUserSchema = createInsertSchema(users);
export const insertFsnIdentitySchema = createInsertSchema(fsnIdentities);
export const insertXpActivitySchema = createInsertSchema(xpActivities);
export const insertBadgeSchema = createInsertSchema(badges);
export const insertUserBadgeSchema = createInsertSchema(userBadges);

// FSN Phase-0 specific tables
export const pulseState = pgTable("pulse_state", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  lastChargeAt: timestamp("last_charge_at"),
  streakDays: integer("streak_days").default(0),
  pulseLevel: varchar("pulse_level").default('bright'), // 'bright' | 'dim' | 'dark'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const signals = pgTable("signals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  active: boolean("active").default(false),
  activatedAt: timestamp("activated_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const xpEvents = pgTable("xp_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: varchar("type").notNull(), // 'login' | 'pulse_charge' | 'signal_toggle' | 'claim'
  points: integer("points").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  metadata: jsonb("metadata"), // Additional event data
});

export const abuseLog = pgTable("abuse_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  deviceId: varchar("device_id"),
  ipHash: varchar("ip_hash"),
  event: varchar("event").notNull(), // 'claim' | 'pulse_charge' | 'signal_toggle'
  timestamp: timestamp("timestamp").defaultNow(),
  metadata: jsonb("metadata"),
});

// Phase-0 Zod schemas
export const insertPulseStateSchema = createInsertSchema(pulseState);
export const insertSignalsSchema = createInsertSchema(signals);
export const insertXpEventsSchema = createInsertSchema(xpEvents);
export const insertAbuseLogSchema = createInsertSchema(abuseLog);

// Types
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;
export type FsnIdentity = typeof fsnIdentities.$inferSelect;
export type InsertFsnIdentity = z.infer<typeof insertFsnIdentitySchema>;
export type XpActivity = typeof xpActivities.$inferSelect;
export type InsertXpActivity = z.infer<typeof insertXpActivitySchema>;
export type Badge = typeof badges.$inferSelect;
export type UserBadge = typeof userBadges.$inferSelect;
export type GlobalStats = typeof globalStats.$inferSelect;

// Phase-0 types
export type PulseState = typeof pulseState.$inferSelect;
export type InsertPulseState = z.infer<typeof insertPulseStateSchema>;
export type Signal = typeof signals.$inferSelect;
export type InsertSignal = z.infer<typeof insertSignalsSchema>;
export type XpEvent = typeof xpEvents.$inferSelect;
export type InsertXpEvent = z.infer<typeof insertXpEventsSchema>;
export type AbuseLog = typeof abuseLog.$inferSelect;
export type InsertAbuseLog = z.infer<typeof insertAbuseLogSchema>;
